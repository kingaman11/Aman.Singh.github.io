import fs from "node:fs/promises";
import assert from "node:assert/strict";
import { render } from "../.prerender/prerender.js";
const template = await fs.readFile("dist/index.html", "utf8");
const markup = await render();
assert.match(markup, /<main\b/, "Prerender must contain the portfolio, not a loading state");
assert.match(markup, /Turning complexity into/);
const html = template.replace('<div id="root"></div>', '<div id="root">' + markup + '</div>');
for (const [label, pattern] of [
  ["description", /<meta name="description"/g],
  ["viewport", /<meta name="viewport"/g],
  ["canonical", /<link rel="canonical"/g],
  ["Open Graph title", /<meta property="og:title"/g],
]) assert.equal([...html.matchAll(pattern)].length, 1, label + " must occur exactly once");
assert.match(html, /id="contact"/);
assert.match(html, /id="alert-lab"/);
await fs.writeFile("dist/index.html", html);
console.log("Prerender verified: full portfolio HTML and unique search metadata.");
