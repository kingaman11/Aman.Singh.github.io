<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Theme: light is default; dark mode is the `.dark` class on <html>, set early by an inline script in __root and persisted in localStorage — keeps first paint flash-free.
- Illustrations are inline SVG using semantic tokens only; intentionally dark panels use the `ink` / `ink-foreground` tokens so they stay dark in both themes.
- Alert Lab model lives in src/lib/alert-lab.ts as pure functions with bundled synthetic data; alert logic must never read ground-truth labels (only evaluate() may) — keeps the comparison honest and testable.
- Diagram workflows declare data-sequence owners with millisecond data-stage/data-path windows on actual nodes/connectors; use-diagram-motion runs one bounded timeline per visible owner, restoring static styles on cancellation, while chart entrances remain one-shot — declarative timing keeps stage order honest and lifecycle cleanup centralized.
- Nav scrollspy mapping lives in SPY_ANCHORS (src/hooks/use-scroll-spy.ts); nested anchors come later in the list so they win while in view.
