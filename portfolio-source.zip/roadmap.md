# Workflow continuity
- [ ] Sequence Mexico, Guardian, Partner and remaining meaningful workflows.
- [ ] Audit static/chart previews and verify complete cycles, cleanup, themes, phones and tests.