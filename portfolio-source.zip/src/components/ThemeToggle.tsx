import { Moon, Sun } from "lucide-react";
import { useEffect, useState } from "react";

export const THEME_KEY = "as-theme";

export const themeInitScript = `(function(){try{if(localStorage.getItem("${THEME_KEY}")==="dark")document.documentElement.classList.add("dark")}catch(e){}setTimeout(function(){document.documentElement.classList.add("intro-done")},2000)})();`;

export function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => {
    setDark(document.documentElement.classList.contains("dark"));
  }, []);
  const label = dark ? "Switch to light mode" : "Switch to dark mode";
  const toggle = () => {
    const next = !dark;
    const apply = () => document.documentElement.classList.toggle("dark", next);
    const doc = document as Document & { startViewTransition?: (cb: () => void) => unknown };
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (doc.startViewTransition && !reduce) {
      try { doc.startViewTransition(apply); } catch { apply(); }
    } else apply();
    try {
      localStorage.setItem(THEME_KEY, next ? "dark" : "light");
    } catch {
      /* storage unavailable */
    }
    setDark(next);
  };
  return (
    <button
      type="button"
      onClick={toggle}
      aria-label={label}
      title={label}
      className="flex h-10 w-10 items-center justify-center rounded-full border border-border text-muted-foreground hover:border-primary hover:text-primary"
    >
      <span key={dark ? "sun" : "moon"} className="theme-icon flex">{dark ? <Sun size={18} /> : <Moon size={18} />}</span>
    </button>
  );
}
