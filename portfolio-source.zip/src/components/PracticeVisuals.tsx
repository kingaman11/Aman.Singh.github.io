const mono = { fontFamily: "var(--font-mono)" } as const;

export function EventVisual() {
  const phases = [
    { t: "Pre-event", s: "Plan" },
    { t: "Live event", s: "Monitor" },
    { t: "Review", s: "Improve" },
  ];
  return (
    <svg data-sequence viewBox="0 0 360 240" role="img" aria-labelledby="ev-t ev-d" className="h-auto w-full">
      <title id="ev-t">Illustrative event operations timeline</title>
      <desc id="ev-d">Three phases: pre-event planning with a runbook, live event monitoring with hourly health signals, and post-event review with root-cause analysis feeding back into the playbook.</desc>
      <rect width="360" height="240" rx="14" className="fill-card stroke-border" />
      <path data-trace data-path="900:1500" d="M49 56 H171" strokeWidth="2" className="stroke-foreground/20" />
      <path data-trace data-path="2400:3000" d="M189 56 H311" strokeWidth="2" className="stroke-foreground/20" />
      {phases.map((p, i) => {
        const x = 40 + i * 140;
        return (
          <g key={p.t} data-stage={['0:1000', '1500:2500', '3000:4200'][i]}>
            <circle cx={x} cy="56" r="9" strokeWidth="2" className={i === 1 ? "fill-primary stroke-primary" : "fill-card stroke-foreground/60"} />
            <text x={x} y="30" fontSize="11" textAnchor="middle" style={mono} className="fill-muted-foreground">{p.t}</text>
            <text x={x} y="86" fontSize="14" textAnchor="middle" className="fill-foreground">{p.s}</text>
          </g>
        );
      })}
      {/* runbook */}
      <g transform="translate(14,104)">
        <rect width="104" height="96" rx="10" className="fill-muted" />
        <text x="12" y="20" fontSize="9" style={mono} className="fill-muted-foreground">RUNBOOK</text>
        {[0, 1, 2, 3].map((r) => (
          <g key={r} transform={`translate(12,${32 + r * 15})`}>
            <rect width="8" height="8" rx="2" className={r < 2 ? "fill-primary" : "fill-card stroke-foreground/40"} />
            <rect x="14" y="2" width={60 - r * 8} height="4" rx="2" className="fill-foreground/25" />
          </g>
        ))}
      </g>
      {/* health signal */}
      <g transform="translate(128,104)">
        <rect width="104" height="96" rx="10" className="fill-ink" />
        <text x="12" y="20" fontSize="9" style={mono} className="fill-ink-foreground/70">HOURLY HEALTH</text>
        {[22, 30, 26, 34, 28, 36, 32].map((h, i) => (
          <rect data-chart-bar key={i} x={12 + i * 12} y={84 - h} width="7" height={h} rx="2" className={i === 6 ? "fill-primary" : "fill-ink-foreground/30"} />
        ))}
      </g>
      {/* root cause */}
      <g transform="translate(242,104)">
        <rect width="104" height="96" rx="10" className="fill-accent" />
        <text x="12" y="20" fontSize="9" style={mono} className="fill-accent-foreground">ROOT CAUSE</text>
        <circle cx="52" cy="44" r="7" className="fill-accent-foreground" />
        {[22, 52, 82].map((x) => (
          <g key={x}>
            <line x1="52" y1="51" x2={x} y2="74" className="stroke-accent-foreground/50" />
            <circle cx={x} cy="78" r="5" className="fill-card stroke-accent-foreground" />
          </g>
        ))}
      </g>
      <path data-trace data-path="4200:6500" d="M320 66 H352 V212 Q352 228 336 228 H24 Q8 228 8 212 V66 H32" fill="none" strokeDasharray="3 4" strokeWidth="1.5" markerEnd="url(#ev-arr)" className="stroke-primary" />
      <defs>
        <marker id="ev-arr" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto">
          <path d="M0 0 L10 5 L0 10z" className="fill-primary" />
        </marker>
      </defs>
    </svg>
  );
}

export function MexicoVisual() {
  const lanes = ["Channels", "Banks", "Networks"];
  return (
    <svg data-sequence viewBox="0 0 360 240" role="img" aria-labelledby="mx-t mx-d" className="h-auto w-full">
      <title id="mx-t">Illustrative Mexico payment test coverage</title>
      <desc id="mx-d">A stylized Mexico silhouette with local and cross-border markers connects to three test lanes, channels, banks and networks, which converge on test, diagnose and coordinate steps. Not real geography or traffic.</desc>
      <rect width="360" height="240" rx="14" className="fill-card stroke-border" />
      {/* stylized silhouette */}
      <path
        d="M18 46 L58 40 L92 52 L104 74 L120 86 L118 104 L132 118 L148 120 L156 132 L140 142 L118 136 L96 124 L74 104 L60 82 L40 66 Z M30 52 L26 90 L36 104"
        fill="none"
        strokeWidth="1.5"
        strokeLinejoin="round"
        className="stroke-foreground/40 fill-muted"
      />
      <circle data-stage="0:1000" cx="96" cy="100" r="5" className="fill-primary" />
      <circle cx="60" cy="44" r="4" className="fill-card stroke-primary" strokeWidth="2" />
      <text x="20" y="166" fontSize="9" style={mono} className="fill-muted-foreground">● LOCAL</text>
      <text x="80" y="166" fontSize="9" style={mono} className="fill-muted-foreground">○ CROSS-BORDER</text>
      {lanes.map((l, i) => {
        const y = 52 + i * 40;
        return (
          <g key={l}>
            <path data-trace data-path={`${600 + i * 180}:${1600 + i * 180}`} d={`M100 100 C 140 100, 150 ${y}, 186 ${y}`} fill="none" strokeWidth="1.5" className="stroke-primary/50" />
            <g data-stage={`${1500 + i * 180}:${2400 + i * 180}`}>
              <rect x="186" y={y - 14} width="98" height="28" rx="14" className="fill-accent" />
              <text x="235" y={y + 4} fontSize="11" textAnchor="middle" className="fill-accent-foreground">{l}</text>
            </g>
            <path data-trace data-path={`${2400 + i * 180}:${3200 + i * 180}`} d={`M284 ${y} C 300 ${y}, 304 92, 316 92`} fill="none" strokeWidth="1.5" className="stroke-foreground/30" />
          </g>
        );
      })}
      <circle data-stage="3100:3800" cx="324" cy="92" r="8" className="fill-foreground" />
      {["Test", "Diagnose", "Coordinate"].map((s, i) => (
        <g key={s} data-stage={['4500:5400', '5800:6700', '7100:8000'][i]} transform={`translate(${170 + i * 62},${190})`}>
          <rect width="56" height="26" rx="8" className={i === 2 ? "fill-foreground" : "fill-muted"} />
          <text x="28" y="17" fontSize="9.5" textAnchor="middle" className={i === 2 ? "fill-background" : "fill-foreground"}>{s}</text>
        </g>
      ))}
      <path data-trace data-path="3700:4500" d="M324 100 V174 Q324 180 318 180 H198 V190" fill="none" strokeWidth="1.5" strokeDasharray="3 3" className="stroke-foreground/30" />
      <path data-trace data-path="5400:5800" d="M226 203 H232" strokeWidth="1.5" className="stroke-foreground/50" />
      <path data-trace data-path="6700:7100" d="M288 203 H294" strokeWidth="1.5" className="stroke-foreground/50" />
    </svg>
  );
}

export function GuardianVisual() {
  const steps = [
    { s: "Detect", a: 0, x: 24 },
    { s: "Probe", a: 1, x: 106 },
    { s: "Compare", a: 1, x: 188 },
    { s: "Report", a: 1, x: 270 },
  ];
  return (
    <svg data-sequence viewBox="0 0 360 240" role="img" aria-labelledby="gd-t gd-d" className="h-auto w-full">
      <title id="gd-t">Illustrative two-agent routing concept</title>
      <desc id="gd-d">Concept, in development. Agent 01 detects underperformance. Agent 02 sends a small canary probe on an alternate route, compares results statistically and reports, with a dotted loop back to monitoring. Not deployed.</desc>
      <rect width="360" height="240" rx="14" className="fill-ink" />
      <rect x="14" y="14" width="152" height="22" rx="11" className="fill-primary" />
      <text x="90" y="29" fontSize="10" textAnchor="middle" style={mono} className="fill-primary-foreground">CONCEPT · IN DEVELOPMENT</text>
      <rect x="14" y="52" width="80" height="96" rx="12" fill="none" strokeDasharray="4 4" className="stroke-ink-foreground/40" />
      <text x="54" y="68" fontSize="9" textAnchor="middle" style={mono} className="fill-ink-foreground/70">AGENT 01</text>
      <rect x="98" y="52" width="248" height="96" rx="12" fill="none" strokeDasharray="4 4" className="stroke-ink-foreground/40" />
      <text x="222" y="68" fontSize="9" textAnchor="middle" style={mono} className="fill-ink-foreground/70">AGENT 02</text>
      {steps.map((st, i) => (
        <g key={st.s}>
          <g data-stage={['0:850', '1350:2200', '2700:3550', '4050:4900'][i]}>
            <rect x={st.x} y="82" width="66" height="44" rx="10" className="fill-ink-foreground/15" />
            <text x={st.x + 33} y="100" fontSize="8" textAnchor="middle" style={mono} className="fill-ink-foreground/70">{`0${i + 1}`}</text>
            <text x={st.x + 33} y="115" fontSize="11" textAnchor="middle" className="fill-ink-foreground">{st.s}</text>
          </g>
          {i < 3 && <path data-trace data-path={['850:1350', '2200:2700', '3550:4050'][i]} d={`M${st.x + 66} 104 H${st.x + 82}`} strokeWidth="1.5" className="stroke-ink-foreground/60" />}
        </g>
      ))}
      {/* canary path */}
      <text x="72" y="176" fontSize="9" style={mono} className="fill-ink-foreground/70">PRIMARY ROUTE</text>
      <line x1="150" y1="173" x2="336" y2="173" strokeWidth="3" strokeLinecap="round" className="stroke-ink-foreground/40" />
      <text x="72" y="198" fontSize="9" style={mono} className="fill-ink-foreground/70">CANARY PROBE</text>
      <line x1="150" y1="195" x2="200" y2="195" strokeWidth="3" strokeLinecap="round" className="stroke-primary" />
      <line x1="200" y1="195" x2="336" y2="195" strokeWidth="1" strokeDasharray="2 4" className="stroke-primary/60" />
      <path data-trace data-path="4900:7300" d="M303 126 V150 C303 236,57 236,57 150 V126" fill="none" strokeDasharray="2 4" strokeWidth="1.5" className="stroke-ink-foreground/40" />
    </svg>
  );
}
