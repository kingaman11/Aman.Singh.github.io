import { useId, useMemo, useState } from "react";
import { ChevronDown, RotateCcw } from "lucide-react";
import {
  DEFAULT_SETTINGS, SAMPLES, SCENARIOS, STEP_MIN, evaluate, fmtTime, getScenario,
  type ScenarioId, type Settings,
} from "@/lib/alert-lab";

const W = 800, H = 300, PL = 44, PR = 12, PT = 34, CH = 170, VB = 50; // chart geometry
const YMIN = 86, YMAX = 100;
const x = (i: number) => PL + (i / (SAMPLES - 1)) * (W - PL - PR);
const y = (r: number) => PT + (1 - (Math.max(YMIN, Math.min(YMAX, r)) - YMIN) / (YMAX - YMIN)) * CH;
const mono = { fontFamily: "var(--font-mono)" } as const;
const dash = (n: number | null | undefined, suffix = "") => (n === null || n === undefined ? "—" : `${n}${suffix}`);

export function AlertLab() {
  const [scenario, setScenario] = useState<ScenarioId>("noisy");
  const [s, setS] = useState<Settings>(DEFAULT_SETTINGS);
  const [showTruth, setShowTruth] = useState(true);
  const [method, setMethod] = useState(false);
  const methodId = useId();
  const data = getScenario(scenario);
  const r = useMemo(() => evaluate(data, s), [data, s]);
  const maxVol = Math.max(...data.map((d) => d.volume));
  const set = (k: keyof Settings) => (e: React.ChangeEvent<HTMLInputElement>) => setS({ ...s, [k]: Number(e.target.value) });
  const path = data.map((d, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(d.rate).toFixed(1)}`).join(" ");
  const volTop = PT + CH + 22;
  const delay = r.after.delays.find((d) => d !== null);

  return (
    <section id="alert-lab" aria-labelledby="alert-lab-h" className="mt-24 scroll-mt-20">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="max-w-[65ch]">
          <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Interactive · optional</p>
          <h3 id="alert-lab-h" className="mt-2 font-display text-3xl sm:text-4xl">From alert noise to useful signals</h3>
          <p className="mt-3 text-muted-foreground">Tune a basic threshold and a context layer on the same payment signal, then compare what each would page you about.</p>
        </div>
      </div>
      <p className="mt-5 rounded-xl border border-border bg-muted/60 px-4 py-3 text-sm text-foreground">
        Synthetic payment data. The AI-assisted view is a deterministic simulation, not a live model or measured production result.
      </p>

      <div className="mt-6 overflow-hidden rounded-3xl border border-border bg-card shadow-sm">
        {/* Controls */}
        <div className="grid gap-6 border-b border-border p-5 sm:p-8 lg:grid-cols-[1.1fr_2fr]">
          <fieldset>
            <legend className="text-sm font-medium">Scenario</legend>
            <div className="mt-3 flex flex-wrap gap-2" role="radiogroup" aria-label="Scenario">
              {SCENARIOS.map((sc) => (
                <button key={sc.id} type="button" role="radio" aria-checked={scenario === sc.id} onClick={() => setScenario(sc.id)}
                  className={`min-h-11 rounded-full border px-4 text-sm ${scenario === sc.id ? "border-foreground bg-foreground text-background" : "border-border hover:border-primary hover:text-primary"}`}>
                  {sc.label}
                </button>
              ))}
            </div>
            <p className="mt-3 text-sm text-muted-foreground">{SCENARIOS.find((x) => x.id === scenario)?.blurb} Switching scenarios keeps your settings.</p>
            <button type="button" onClick={() => { setScenario("noisy"); setS(DEFAULT_SETTINGS); setShowTruth(true); }}
              className="mt-3 inline-flex min-h-11 items-center gap-2 text-sm font-medium text-foreground underline decoration-border underline-offset-4 hover:text-primary">
              <RotateCcw size={14} aria-hidden="true" /> Reset all
            </button>
          </fieldset>
          <div className="grid gap-5 sm:grid-cols-3">
            <Slider label="Alert threshold" hint="Shared by both views" value={s.threshold} display={`below ${s.threshold.toFixed(1)}%`} min={90} max={99} step={0.5} onChange={set("threshold")} />
            <Slider label="Persistence" hint="AI-assisted only" value={s.persistence} display={`${s.persistence} sample${s.persistence > 1 ? "s" : ""} (${s.persistence * STEP_MIN} min)`} min={1} max={4} step={1} onChange={set("persistence")} />
            <Slider label="Minimum volume" hint="AI-assisted only" value={s.minVolume} display={`${s.minVolume.toLocaleString("en-US")} txns / 15 min`} min={0} max={2000} step={100} onChange={set("minVolume")} />
          </div>
        </div>

        {/* Chart */}
        <figure className="viz surface-light bg-fine-grid border-b border-border p-4 sm:p-6">
          <div className="overflow-x-auto">
            <svg viewBox={`0 0 ${W} ${H}`} className="block w-full min-w-[640px] rounded-xl bg-card" role="img" aria-labelledby={`${methodId}-cap`}>
              {showTruth && r.eps.map((e) => (
                <rect key={e.start} x={x(e.start) - 3} y={PT} width={x(e.end) - x(e.start) + 6} height={CH} className="fill-foreground/[0.07]" />
              ))}
              {[88, 92, 96, 100].map((v) => (
                <g key={v}>
                  <line x1={PL} x2={W - PR} y1={y(v)} y2={y(v)} className="stroke-foreground/10" />
                  <text x={PL - 6} y={y(v) + 4} textAnchor="end" fontSize="11" className="fill-muted-foreground" style={mono}>{v}%</text>
                </g>
              ))}
              {[0, 4, 8, 12, 16, 20].map((h) => (
                <text key={h} x={x((h * 60) / STEP_MIN)} y={H - 4} textAnchor="middle" fontSize="11" className="fill-muted-foreground" style={mono}>{fmtTime(h * 60)}</text>
              ))}
              <text x={PL} y={14} fontSize="11" className="fill-muted-foreground" style={mono}>Authorization rate</text>
              <g className="lab-move" style={{ transform: `translateY(${y(s.threshold)}px)` }}>
                <line x1={PL} x2={W - PR} y1={0} y2={0} strokeDasharray="5 4" strokeWidth="1.5" className="stroke-warn" />
                <text x={W - PR} y={-5} textAnchor="end" fontSize="11" className="fill-warn" style={mono}>threshold {s.threshold}%</text>
              </g>
              <g key={`line-${scenario}`} className="lab-pop"><path data-chart-line d={path} fill="none" strokeWidth="1.75" className="stroke-foreground/70" /></g>
              {r.base.map((i) => <line key={`b${scenario}${i}`} x1={x(i)} x2={x(i)} y1={PT - 12} y2={PT - 4} strokeWidth="2" className="lab-pop stroke-warn" />)}
              {r.tri.notifications.map((n) => (
                <g key={`n${scenario}${n.start}`} className="lab-pop">
                  <line x1={x(n.start)} x2={x(n.start)} y1={PT} y2={PT + CH} className="stroke-primary/50" strokeDasharray="2 3" />
                  <rect x={x(n.start) - 5} y={PT - 25} width="10" height="10" transform={`rotate(45 ${x(n.start)} ${PT - 20})`} className="fill-primary" />
                </g>
              ))}
              <g key={`vol-${scenario}`} className="lab-pop">
              {data.map((d, i) => (
                <rect data-chart-bar key={i} x={x(i) - 2.5} width="5" y={volTop + VB * (1 - d.volume / maxVol)} height={VB * (d.volume / maxVol)}
                  className={`lab-fill ${d.volume < s.minVolume ? "fill-foreground/15" : "fill-foreground/35"}`} />
              ))}
              </g>
              <text x={PL - 6} y={volTop + 10} textAnchor="end" fontSize="10" className="fill-muted-foreground" style={mono}>vol</text>
            </svg>
          </div>
          <figcaption id={`${methodId}-cap`} className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-muted-foreground">
            <Legend swatch={<span className="h-3 w-0.5 bg-warn" />} text="Threshold alert" />
            <Legend swatch={<span className="h-2.5 w-2.5 rotate-45 bg-primary" />} text="AI-assisted notification" />
            <Legend swatch={<span className="h-0 w-4 border-t-2 border-dashed border-warn" />} text="Threshold line" />
            <Legend swatch={<span className="h-3 w-2 bg-foreground/15" />} text="Volume below minimum" />
            <label className="inline-flex min-h-11 cursor-pointer items-center gap-2 text-foreground">
              <input type="checkbox" checked={showTruth} onChange={(e) => setShowTruth(e.target.checked)} className="h-4 w-4 accent-[var(--color-foreground)]" />
              <span className="inline-block h-3 w-4 bg-foreground/15" aria-hidden="true" /> Show true incident windows (evaluation only)
            </label>
            <span className="w-full">Synthetic data · 24 hours at 15-minute samples. {r.base.length} samples breach the threshold; {r.eps.length} true incident{r.eps.length === 1 ? "" : "s"}.</span>
          </figcaption>
        </figure>

        {/* Before / after */}
        <div className="grid lg:grid-cols-2" aria-live="polite">
          <Panel title="Threshold alerting" sub="Pages on every sample below the threshold."
            stats={[["Alerts sent", r.before.alerts], ["Incidents detected", `${r.before.detected}/${r.before.total}`], ["Missed", r.before.missed], ["Noise alerts", r.before.falseAlerts]]}>
            <Feed empty="No samples breach the threshold." items={r.base.slice(0, 40).map((i) => ({ k: i, t: data[i]!.t, v: data[i]!.rate, text: `Below ${s.threshold}% · ${data[i]!.volume.toLocaleString("en-US")} txns` }))} more={r.base.length - 40} />
          </Panel>
          <Panel ai title="AI-assisted triage · simulated" sub="Same breaches, filtered for volume and persistence, then grouped."
            stats={[["Notifications", r.after.alerts], ["Incidents detected", `${r.after.detected}/${r.after.total}`], ["Missed", r.after.missed], ["Noise notifications", r.after.falseAlerts]]}>
            <Feed empty="No notifications at these settings." items={r.tri.notifications.map((n) => ({ k: n.start, t: data[n.start]!.t, v: data[n.start]!.rate, text: n.explanation }))} />
          </Panel>
        </div>

        {/* Pipeline */}
        <div className="border-t border-border p-5 sm:p-8">
          <p className="text-sm font-medium">Raw breaches → filtered candidates → grouped notifications</p>
          <ol className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-5">
            <Step n={r.tri.raw} label="Raw breaches" />
            <Step n={r.tri.lowVolume} label="Filtered · low volume" />
            <Step n={r.tri.held} label="Held · not yet persistent" />
            <Step n={r.tri.grouped} label="Grouped into an open notification" />
            <Step n={r.tri.notifications.length} label="Notifications" strong />
          </ol>
          <p className="mt-4 max-w-[70ch] text-sm leading-relaxed text-muted-foreground">
            {r.reduction === null
              ? "No samples breach the threshold, so there is nothing to reduce."
              : `${r.tri.raw} threshold alerts became ${r.tri.notifications.length} notification${r.tri.notifications.length === 1 ? "" : "s"} (${r.reduction}% fewer pages), driven by filtering and grouping — not a measured false-positive rate.`}
            {" "}
            {r.after.missed > r.before.missed
              ? `At these settings the simulated triage misses ${r.after.missed - r.before.missed} incident${r.after.missed - r.before.missed > 1 ? "s" : ""} the threshold caught.`
              : delay !== undefined && delay > 0
                ? `Persistence adds a ${delay}-minute detection delay on the first incident.`
                : ""}
          </p>
        </div>

        {/* Method */}
        <div className="border-t border-border px-5 pb-5 sm:px-8 sm:pb-8">
          <button type="button" aria-expanded={method} aria-controls={methodId} onClick={() => setMethod(!method)}
            className="mt-3 inline-flex min-h-11 items-center gap-2 text-sm font-medium hover:text-primary">
            <ChevronDown size={16} aria-hidden="true" className={`transition-transform ${method ? "rotate-180" : ""}`} /> How this works
          </button>
          <div id={methodId} hidden={!method} className="mt-2 grid max-w-[75ch] gap-3 text-sm leading-relaxed text-muted-foreground">
            <p><strong className="text-foreground">Data.</strong> 96 synthetic 15-minute samples of authorization rate and transaction volume, generated from a fixed seed per scenario. Incident windows are labels used only to score results; the alert logic never reads them.</p>
            <p><strong className="text-foreground">Threshold alerting.</strong> One alert per sample below the threshold.</p>
            <p><strong className="text-foreground">Simulated AI-assisted triage.</strong> Rule-based stand-in for a context layer: ignore breaches below the minimum volume; wait until a breach persists for N consecutive samples (using only past and current samples); group confirmed breaches within one quiet sample into one open notification; write a short explanation from the observed values.</p>
            <p><strong className="text-foreground">Scoring.</strong> Incidents count as detected if any alert or notification lands inside the window. Noise means an alert or notification that touches no incident window. Grouped follow-ons are not counted as noise.</p>
            <p><strong className="text-foreground">Limits.</strong> Educational sketch, not a production recommendation or a real model. Runs entirely in your browser with no network calls.</p>
          </div>
        </div>
      </div>
    </section>
  );
}

function Slider(p: { label: string; hint: string; value: number; display: string; min: number; max: number; step: number; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void }) {
  const id = useId();
  return (
    <div>
      <label htmlFor={id} className="text-sm font-medium">{p.label}</label>
      <p className="font-mono text-sm text-foreground" aria-hidden="true">{p.display}</p>
      <input id={id} type="range" min={p.min} max={p.max} step={p.step} value={p.value} onChange={p.onChange} aria-valuetext={p.display}
        className="mt-2 h-11 w-full cursor-pointer accent-[var(--color-primary)]" />
      <p className="text-xs text-muted-foreground">{p.hint}</p>
    </div>
  );
}

function Legend({ swatch, text }: { swatch: React.ReactNode; text: string }) {
  return <span className="inline-flex items-center gap-2"><span aria-hidden="true" className="inline-flex w-4 justify-center">{swatch}</span>{text}</span>;
}

function Panel({ title, sub, stats, ai, children }: { title: string; sub: string; stats: [string, string | number][]; ai?: boolean; children: React.ReactNode }) {
  return (
    <div className={`min-w-0 p-5 sm:p-8 ${ai ? "border-t border-border lg:border-l lg:border-t-0" : ""}`}>
      <div className="flex items-center gap-2">
        <span aria-hidden="true" className={ai ? "h-2.5 w-2.5 rotate-45 bg-primary" : "h-3 w-0.5 bg-warn"} />
        <h4 className="font-display text-xl">{title}</h4>
      </div>
      <p className="mt-1 text-sm text-muted-foreground">{sub}</p>
      <dl className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {stats.map(([k, v]) => (
          <div key={k} className="rounded-xl border border-border bg-background p-3">
            <dt className="text-xs text-muted-foreground">{k}</dt>
            <dd key={String(v)} className="lab-pop mt-1 font-display text-2xl tabular-nums">{dash(v as number)}</dd>
          </div>
        ))}
      </dl>
      {children}
    </div>
  );
}

function Feed({ items, empty, more = 0 }: { items: { k: number; t: number; v: number; text: string }[]; empty: string; more?: number }) {
  if (!items.length) return <p className="mt-5 text-sm text-muted-foreground">{empty}</p>;
  return (
    <ul className="mt-5 max-h-64 space-y-1.5 overflow-y-auto pr-1 text-sm" aria-label="Alert feed">
      {items.map((it) => (
        <li key={it.k} className="grid grid-cols-[3.5rem_3.5rem_1fr] gap-2 rounded-lg border border-border px-3 py-2">
          <span className="font-mono text-xs text-muted-foreground">{fmtTime(it.t)}</span>
          <span className="font-mono text-xs tabular-nums">{it.v}%</span>
          <span className="text-xs leading-snug text-muted-foreground">{it.text}</span>
        </li>
      ))}
      {more > 0 && <li className="px-3 py-1 text-xs text-muted-foreground">+{more} more</li>}
    </ul>
  );
}

function Step({ n, label, strong }: { n: number; label: string; strong?: boolean }) {
  return (
    <li className={`rounded-xl border p-3 ${strong ? "col-span-2 sm:col-span-1 border-primary/50 bg-accent/40" : "border-border bg-background"}`}>
      <p key={n} className="lab-pop font-display text-2xl tabular-nums">{n}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </li>
  );
}
