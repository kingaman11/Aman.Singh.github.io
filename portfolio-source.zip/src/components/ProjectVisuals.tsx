import davisShot from "@/assets/davis-restaurant-explorer.jpg";

const mono = { fontFamily: "var(--font-mono)" } as const;

export function DavisPreview() {
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-inset p-2">
      <img
        src={davisShot}
        alt="Screenshot of the Davis restaurant Shiny app: dropdowns for price, type of food and restaurant name beside a review word cloud."
        loading="lazy"
        width={1200}
        height={428}
        className="h-auto w-full rounded-md"
      />
    </div>
  );
}

export function BasketballVisual() {
  const pts: [number, number][] = [
    [70, 120], [92, 88], [110, 132], [128, 70], [140, 104], [158, 120], [172, 84], [190, 140],
    [206, 96], [222, 64], [236, 118], [252, 90], [268, 130], [284, 76], [300, 108], [96, 60], [180, 56], [262, 150],
  ];
  return (
    <svg viewBox="0 0 360 220" role="img" aria-labelledby="bb-t bb-d" className="h-auto w-full">
      <title id="bb-t">Illustrative scatter plot of BMI and performance</title>
      <desc id="bb-d">Scattered sample points on BMI and performance axes with a basketball motif. Illustrative data, not project results; no trend line is shown.</desc>
      <rect width="360" height="220" rx="14" className="fill-card stroke-border" />
      <line x1="50" y1="170" x2="330" y2="170" strokeWidth="1.5" className="stroke-foreground/50" />
      <line x1="50" y1="170" x2="50" y2="34" strokeWidth="1.5" className="stroke-foreground/50" />
      {[80, 130, 180, 230, 280].map((x) => <line key={x} x1={x} y1="40" x2={x} y2="170" className="stroke-foreground/10" />)}
      {pts.map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r="5" className={i % 5 === 0 ? "fill-primary" : "fill-primary/35"} />
      ))}
      <text x="190" y="196" fontSize="11" textAnchor="middle" style={mono} className="fill-muted-foreground">BMI</text>
      <text x="24" y="104" fontSize="11" textAnchor="middle" transform="rotate(-90 24 104)" style={mono} className="fill-muted-foreground">Performance</text>
      <g transform="translate(312,40)" fill="none" strokeWidth="1.5" className="stroke-foreground/60">
        <circle r="14" />
        <path d="M-14 0 H14 M0 -14 V14 M-10 -10 C -4 -4, -4 4, -10 10 M10 -10 C 4 -4, 4 4, 10 10" />
      </g>
    </svg>
  );
}

export function EconometricsVisual() {
  const coefs = [
    { y: 128, x: 220, w: 40 },
    { y: 152, x: 196, w: 56 },
    { y: 176, x: 238, w: 34 },
  ];
  return (
    <svg viewBox="0 0 360 220" role="img" aria-labelledby="ec-t ec-d" className="h-auto w-full">
      <title id="ec-t">Illustrative econometrics workflow</title>
      <desc id="ec-d">A dataset flows into a research question and then a model output, shown as a neutral coefficient-style plot. Illustrative analysis, not project results.</desc>
      <rect width="360" height="220" rx="14" className="fill-card stroke-border" />
      {["Dataset", "Question", "Model"].map((s, i) => (
        <g key={s} transform={`translate(${20 + i * 112},22)`}>
          <rect width="96" height="40" rx="10" className={i === 2 ? "fill-ink" : "fill-accent"} />
          <text x="48" y="25" fontSize="12" textAnchor="middle" className={i === 2 ? "fill-ink-foreground" : "fill-accent-foreground"}>{s}</text>
          {i < 2 && <path d="M98 20 H110" strokeWidth="1.5" className="stroke-primary" />}
        </g>
      ))}
      <text x="20" y="98" fontSize="10" style={mono} className="fill-muted-foreground">.do · OUTPUT</text>
      <line x1="220" y1="110" x2="220" y2="190" strokeDasharray="3 3" className="stroke-foreground/40" />
      {coefs.map((c, i) => (
        <g key={i}>
          <text x="20" y={c.y + 4} fontSize="10" style={mono} className="fill-muted-foreground">{`x${i + 1}`}</text>
          <line x1={c.x - c.w / 2} y1={c.y} x2={c.x + c.w / 2} y2={c.y} strokeWidth="2" className="stroke-foreground/50" />
          <circle cx={c.x} cy={c.y} r="5" className="fill-primary" />
        </g>
      ))}
    </svg>
  );
}
