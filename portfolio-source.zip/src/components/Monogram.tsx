import { useRef } from "react";

/** Code-native AS signature mark; draws once on load, pulses site diagrams on activation. */
export function Monogram() {
  const timer = useRef<number | undefined>(undefined);
  const pulse = () => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const root = document.documentElement;
    root.classList.remove("signal-pulse");
    void root.offsetWidth;
    root.classList.add("signal-pulse");
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => root.classList.remove("signal-pulse"), 1300);
  };
  return (
    <a
      href="#top"
      aria-label="Aman Singh, back to top"
      onClick={pulse}
      className="monogram group flex h-11 w-11 items-center justify-center rounded-lg bg-foreground text-background"
    >
      <svg viewBox="0 0 44 44" width="44" height="44" aria-hidden="true">
        <rect className="mono-frame" x="5" y="5" width="34" height="34" rx="7" fill="none" stroke="currentColor" strokeWidth="1" pathLength="100" />
        <text className="mono-letters" x="22" y="28.5" textAnchor="middle" fontSize="16" fill="currentColor" stroke="currentColor" strokeWidth="0.6" pathLength="100" style={{ fontFamily: "var(--font-display)", letterSpacing: "0.5px" }}>AS</text>
        <circle className="mono-dot" cx="34" cy="10" r="1.6" fill="var(--color-primary)" />
      </svg>
    </a>
  );
}
