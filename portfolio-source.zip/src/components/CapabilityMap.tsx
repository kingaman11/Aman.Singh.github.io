const stages = [
  { n: "01", t: "Monitor", d: "Watch the signals", items: ["Grafana", "Datadog", "Pagos", "Pulse"] },
  { n: "02", t: "Analyze", d: "Make sense of the data", items: ["Python", "SQL", "R", "Excel", "Power BI", "Tableau"] },
  { n: "03", t: "Automate", d: "Remove repetitive work", items: ["LLM workflows", "Claude Code", "Codex", "Power Automate"] },
  {
    n: "04",
    t: "Decide",
    d: "Turn evidence into action",
    items: ["Payment performance", "Pricing strategy", "Incident management", "Root-cause analysis", "PSP partnerships", "Runbook design", "Cross-functional leadership"],
  },
];

export function CapabilityMap() {
  return (
    <div>
      <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Expertise</p>
      <h3 id="expertise-h" className="mt-2 font-display text-3xl sm:text-4xl">From signals to decisions</h3>
      <p className="mt-2 max-w-xl text-sm text-muted-foreground">A conceptual map of how the tools and skills I use relate — not literal integrations.</p>
      <ol data-sequence className="mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {stages.map((s, i) => (
          <li key={s.t} className="relative flex flex-col rounded-2xl border border-border bg-card p-6">
            {i < stages.length - 1 && (
              <span data-trace-html data-path={['900:1600', '2500:3200', '4100:4800'][i]} aria-hidden="true" className="absolute -bottom-4 left-10 h-4 w-px bg-primary/50 xl:-right-4 xl:bottom-auto xl:left-auto xl:top-12 xl:h-px xl:w-4" />
            )}
            <div className="flex items-center gap-3">
              <span data-stage={['0:900', '1600:2500', '3200:4100', '4800:6100'][i]} className={`flex h-9 w-9 items-center justify-center rounded-full font-mono text-xs ${i === 3 ? "bg-ink text-ink-foreground" : "bg-accent text-accent-foreground"}`}>{s.n}</span>
              <div>
                <p className="font-display text-xl leading-tight">{s.t}</p>
                <p className="text-xs text-muted-foreground">{s.d}</p>
              </div>
            </div>
            <ul className="mt-5 flex flex-wrap gap-2">
              {s.items.map((it) => (
                <li key={it} className="rounded-full border border-border bg-background px-3 py-1 text-sm">{it}</li>
              ))}
            </ul>
          </li>
        ))}
      </ol>
    </div>
  );
}
