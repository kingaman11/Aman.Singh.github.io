import { ArrowDown, ArrowUpRight } from "lucide-react";
import { useId, useState, type ReactNode } from "react";
import { RokuVisual } from "./WorkFeatures";

const mono = { fontFamily: "var(--font-mono)" } as const;

function ParkingVisual() {
  const trend = [40, 46, 52, 64, 78, 86, 82, 74, 70, 76, 84, 72, 58, 48];
  const line = trend.map((v, i) => `${i === 0 ? "M" : "L"}${32 + i * 23},${198 - v * 0.45}`).join(" ");
  const peaks = [18, 26, 40, 58, 50, 34, 22];
  return (
    <>
    <svg viewBox="0 0 320 340" role="img" aria-labelledby="pkm-t pkm-d" className="h-auto w-full sm:hidden">
      <title id="pkm-t">Illustrative parking operations dashboard</title>
      <desc id="pkm-d">Simplified schematic dashboard with an executive and deep dive view toggle, a utilization trend, a hotspots panel and an overflow headroom panel. Illustrative preview, not live data.</desc>
      <rect width="320" height="340" rx="16" className="fill-card stroke-border" />
      <rect x="16" y="16" width="288" height="40" rx="20" className="fill-muted" />
      <rect x="20" y="20" width="142" height="32" rx="16" className="fill-ink" />
      <text x="91" y="42" fontSize="16" fontWeight="600" textAnchor="middle" className="fill-ink-foreground">Executive</text>
      <text x="233" y="42" fontSize="16" textAnchor="middle" className="fill-muted-foreground">Deep dive</text>
      <rect x="16" y="70" width="288" height="110" rx="12" className="fill-accent" />
      <text x="30" y="98" fontSize="17" fontWeight="600" className="fill-accent-foreground">Utilization</text>
      <path data-chart-line d={trend.map((v, i) => `${i === 0 ? "M" : "L"}${30 + i * 20},${168 - v * 0.6}`).join(" ")} fill="none" strokeWidth="3" strokeLinejoin="round" className="stroke-primary" />
      <rect x="16" y="194" width="140" height="130" rx="12" className="fill-ink" />
      <text x="30" y="222" fontSize="17" fontWeight="600" className="fill-ink-foreground">Hotspots</text>
      {[90, 70, 50].map((w, i) => (
        <g key={i} transform={`translate(30,${242 + i * 24})`}>
          <rect width="112" height="12" rx="6" className="fill-ink-foreground/15" />
          <rect width={w * 1.2} height="12" rx="6" className={i === 0 ? "fill-primary" : "fill-ink-foreground/50"} />
        </g>
      ))}
      <rect x="164" y="194" width="140" height="130" rx="12" className="fill-background stroke-border" />
      <text x="178" y="222" fontSize="17" fontWeight="600" className="fill-foreground">Overflow</text>
      {[0, 1, 2, 3].map((i) => (
        <rect key={i} x={178 + (i % 2) * 58} y={240 + Math.floor(i / 2) * 40} width="50" height="32" rx="6" className={i < 3 ? "fill-accent" : "fill-muted stroke-border"} />
      ))}
    </svg>
    <svg viewBox="0 0 480 320" role="img" aria-labelledby="pk-t pk-d" className="hidden h-auto w-full sm:block">
      <title id="pk-t">Illustrative parking operations dashboard</title>
      <desc id="pk-d">Schematic dashboard with an executive summary and deep dive view toggle, filter controls, utilization tiles, a system occupancy trend line, a peak-hours bar chart, and hotspot and overflow headroom panels. Illustrative preview, not live data.</desc>
      <rect width="480" height="320" rx="16" className="fill-card stroke-border" />
      <text x="20" y="28" fontSize="11" style={mono} className="fill-muted-foreground">PARKING OPERATIONS · SAMPLE</text>
      <g transform="translate(300,14)">
        <rect width="164" height="24" rx="12" className="fill-muted" />
        <rect x="2" y="2" width="82" height="20" rx="10" className="fill-ink" />
        <text x="43" y="16" fontSize="9.5" textAnchor="middle" className="fill-ink-foreground">Executive</text>
        <text x="124" y="16" fontSize="9.5" textAnchor="middle" className="fill-muted-foreground">Deep dive</text>
      </g>
      {["Portfolio", "Dates", "Hours", "Alert threshold"].map((f, i) => (
        <g key={f} transform={`translate(${20 + i * 112},50)`}>
          <rect width="104" height="22" rx="6" className="fill-background stroke-border" />
          <text x="10" y="15" fontSize="9.5" className="fill-muted-foreground">{f} ▾</text>
        </g>
      ))}
      {["Occupancy", "Utilization", "Hotspots"].map((k, i) => (
        <g key={k} transform={`translate(${20 + i * 150},84)`}>
          <rect width="140" height="44" rx="10" className={i === 1 ? "fill-accent" : "fill-muted"} />
          <text x="12" y="18" fontSize="9.5" style={mono} className={i === 1 ? "fill-accent-foreground" : "fill-muted-foreground"}>{k.toUpperCase()}</text>
          <rect x="12" y="26" width={50 + i * 14} height="8" rx="4" className={i === 1 ? "fill-primary" : "fill-foreground/30"} />
        </g>
      ))}
      <g>
        <rect x="20" y="140" width="320" height="64" rx="10" className="fill-background stroke-border" />
        <text x="30" y="156" fontSize="9" style={mono} className="fill-muted-foreground">SYSTEM OCCUPANCY</text>
        <path data-chart-line d={line} fill="none" strokeWidth="2.5" strokeLinejoin="round" className="stroke-primary" />
      </g>
      <g transform="translate(350,140)">
        <rect width="110" height="64" rx="10" className="fill-background stroke-border" />
        <text x="10" y="16" fontSize="9" style={mono} className="fill-muted-foreground">PEAK HOURS</text>
        {peaks.map((h, i) => (
          <rect data-chart-bar key={i} x={12 + i * 13} y={58 - h * 0.7} width="8" height={h * 0.7} rx="2" className={i === 3 ? "fill-primary" : "fill-foreground/30"} />
        ))}
      </g>
      <g transform="translate(20,216)">
        <rect width="215" height="88" rx="10" className="fill-ink" />
        <text x="12" y="20" fontSize="9" style={mono} className="fill-ink-foreground/80">CONGESTION HOTSPOTS</text>
        {[70, 52, 38].map((w, i) => (
          <g key={i} transform={`translate(12,${32 + i * 17})`}>
            <rect width="190" height="10" rx="5" className="fill-ink-foreground/15" />
            <rect width={w * 2.3} height="10" rx="5" className={i === 0 ? "fill-primary" : "fill-ink-foreground/50"} />
          </g>
        ))}
      </g>
      <g transform="translate(245,216)">
        <rect width="215" height="88" rx="10" className="fill-background stroke-border" />
        <text x="12" y="20" fontSize="9" style={mono} className="fill-muted-foreground">OVERFLOW HEADROOM</text>
        {[0, 1, 2, 3, 4].map((i) => (
          <rect key={i} x={12 + i * 39} y="32" width="32" height="42" rx="6" className={i < 3 ? "fill-accent" : "fill-muted stroke-border"} />
        ))}
      </g>
    </svg>
    </>
  );
}

function Story({
  tag,
  eyebrow,
  title,
  meta,
  problem,
  contribution,
  outcome,
  visual,
  caption,
  action,
  reverse, surface,
  scope,
}: {
  tag: string;
  eyebrow: string;
  title: string;
  meta?: string;
  problem: string;
  contribution: string;
  outcome: string;
  visual: ReactNode;
  caption: string;
  action: ReactNode;
  reverse?: boolean;
  surface?: string;
  scope?: { summary: string; points: string[] };
}) {
  const [open, setOpen] = useState(false);
  const scopeId = useId();
  return (
    <article className="card-lift grid min-w-0 overflow-hidden rounded-3xl border border-border bg-card shadow-sm lg:grid-cols-[1.25fr_1fr]">
      <figure className={`viz ${surface ?? "surface-light"} bg-fine-grid border-b border-border p-4 sm:p-8 lg:border-b-0 ${reverse ? "lg:order-2 lg:border-l" : "lg:border-r"}`}>
        {visual}
        <figcaption className="mt-3 text-xs leading-snug text-muted-foreground">{caption}</figcaption>
      </figure>
      <div className="flex min-w-0 flex-col p-6 sm:p-10">
        <div className="flex flex-wrap items-center gap-2">
          <span className="rounded-full border border-border px-3 py-1 text-xs text-muted-foreground">{tag}</span>
        </div>
        <p className="mt-4 font-mono text-xs uppercase tracking-widest text-muted-foreground">{eyebrow}</p>
        <h3 className="mt-2 font-display text-3xl leading-tight sm:text-4xl">{title}</h3>
        {meta && <p className="mt-2 text-sm text-muted-foreground">{meta}</p>}
        <dl className="mt-6 space-y-4 text-sm leading-relaxed">
          {[
            ["Problem", problem],
            ["Contribution", contribution],
            ["Outcome", outcome],
          ].map(([k, v]) => (
            <div key={k} className="grid gap-1 sm:grid-cols-[7.5rem_1fr] sm:gap-4">
              <dt className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{k}</dt>
              <dd>{v}</dd>
            </div>
          ))}
        </dl>
        {scope && (
          <div className="mt-6 border-t border-border pt-5">
            <p className="text-sm leading-relaxed text-muted-foreground">{scope.summary}</p>
            <button
              type="button"
              aria-expanded={open}
              aria-controls={scopeId}
              onClick={() => setOpen(!open)}
              className="mt-3 inline-flex items-center gap-1 text-sm font-medium text-foreground underline decoration-border underline-offset-4 hover:text-primary hover:decoration-primary"
            >
              {open ? "Hide project scope" : "Show project scope"} <span aria-hidden="true">{open ? "−" : "+"}</span>
            </button>
            <ul id={scopeId} hidden={!open} className="mt-3 space-y-2 text-sm leading-relaxed text-muted-foreground">
              {scope.points.map((p) => (
                <li key={p} className="flex gap-3"><span aria-hidden="true" className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />{p}</li>
              ))}
            </ul>
          </div>
        )}
        <div className="mt-8">{action}</div>
      </div>
    </article>
  );
}

export function FeaturedStories() {
  return (
    <div className="space-y-8">
      <Story
        tag="Academic prototype"
        eyebrow="Georgia Tech master's capstone · Collaborative project"
        title="Parking Intelligence Command Center"
        meta="By Aman Singh & Harkeerat Sidhu"
        problem="Make congestion, capacity and overflow information easier to interpret."
        contribution="Co-developed a Streamlit decision-support dashboard with Harkeerat Sidhu."
        outcome="An interactive capstone prototype with executive and deep-dive views, configurable filters, and PDF reporting."
        scope={{
          summary: "The project explores utilization-based lot recommendations and nearby alternatives, with validation and isolated error handling to keep the dashboard usable.",
          points: [
            "Lot recommendations: ranks parking options for a selected hour using mismatch, underuse and utilization signals.",
            "Nearby alternatives: suggests other lots by combining distance with utilization and recommendation signals (GIS-assisted).",
            "Reliability: column validation, weekday/weekend handling, tab-level error isolation, and cleaner labels and layout.",
            "Transparency: methodology and findings sections are described in the project notes.",
            "Scope as documented by the team; the public demo's current views may differ.",
          ],
        }}
        visual={<ParkingVisual />}
        caption="Illustrative preview · not live data"
        action={
          <div>
            <a
              href="https://parkingdashboard-dq3myljpnwsknjkmadije2.streamlit.app"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-foreground hover:text-background"
            >
              Open dashboard <ArrowUpRight size={16} />
            </a>
            <p className="mt-3 text-xs text-muted-foreground">Hosted on Streamlit; availability may vary.</p>
          </div>
        }
      />
      <Story surface="surface-ink"
        reverse
        tag="Professional work"
        eyebrow="Roku"
        title="Payment performance monitoring"
        problem="Detect payment-health issues across regions and prioritize escalations."
        contribution="Monitored 146+ payment KPIs across 5 regions and introduced LLM-powered alerting and escalation workflows. Managed a senior data analyst and authored the monitoring and escalation playbook."
        outcome="Incident resolution involving $500K+ estimated financial impact; PSP collaboration contributing to a 15 bps COGS improvement."
        visual={<RokuVisual />}
        caption="Illustrative preview · sample data · not live"
        action={
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
            <a href="#payments-practice" className="inline-flex items-center gap-2 rounded-full border border-foreground/30 px-6 py-3 text-sm font-medium transition-colors hover:border-primary hover:text-primary">
              Explore payments work <ArrowDown size={16} />
            </a>
            <a href="#alert-lab" className="inline-flex min-h-11 items-center gap-1 text-sm font-medium underline decoration-border underline-offset-4 hover:text-primary hover:decoration-primary">
              Try alert lab <ArrowDown size={14} />
            </a>
          </div>
        }
      />
    </div>
  );
}
