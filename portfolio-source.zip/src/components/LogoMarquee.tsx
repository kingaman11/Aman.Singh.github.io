import { useState } from "react";
import { Pause, Play } from "lucide-react";
import roku from "@/assets/logos/roku.svg";
import visa from "@/assets/logos/visa.svg";
import chevron from "@/assets/logos/chevron.svg";
import gt from "@/assets/logos/georgia-tech.svg";
import c3 from "@/assets/logos/c3-ai.svg";
import haas from "@/assets/logos/berkeley-haas.svg";
import ucd from "@/assets/logos/uc-davis.svg";

const logos: { name: string; src?: string; h: string }[] = [
  { name: "Roku", src: roku, h: "h-3.5" },
  { name: "Visa", src: visa, h: "h-4" },
  { name: "Chevron", src: chevron, h: "h-6" },
  { name: "Effective AI", h: "" },
  { name: "Georgia Tech", src: gt, h: "h-6" },
  { name: "C3 AI", src: c3, h: "h-5" },
];

function Group({ dup }: { dup?: boolean }) {
  return (
    <ul className={`flex shrink-0 items-center gap-3 pr-3 ${dup ? "marquee-dup" : ""}`} aria-hidden={dup || undefined}>
      {logos.map((l) => (
        <li key={l.name} className="flex h-10 shrink-0 items-center rounded-lg border border-border bg-logo-tile px-3">
          {l.src ? (
            <img src={l.src} alt={dup ? "" : l.name} className={`${l.h} w-auto`} loading="eager" />
          ) : (
            <span className="whitespace-nowrap text-sm font-semibold tracking-tight text-ink">{l.name}</span>
          )}
        </li>
      ))}
    </ul>
  );
}

export function LogoMarquee() {
  const [paused, setPaused] = useState(false);
  return (
    <div className="marquee mt-4 w-full rounded-2xl border border-border bg-card p-3" data-paused={paused}>
      <div className="mb-2 flex items-center justify-between gap-2">
        <p id="exp-across" className="text-xs text-muted-foreground">Experience</p>
        <button
          type="button"
          onClick={() => setPaused(!paused)}
          aria-label={paused ? "Play logo animation" : "Pause logo animation"}
          aria-pressed={paused}
          className="marquee-toggle relative flex h-7 w-7 after:absolute after:-inset-2 after:content-[''] items-center justify-center rounded-full border border-border text-muted-foreground hover:text-primary"
        >
          {paused ? <Play size={12} aria-hidden="true" /> : <Pause size={12} aria-hidden="true" />}
        </button>
      </div>
      <div className="marquee-viewport overflow-hidden" role="region" aria-labelledby="exp-across" tabIndex={-1}>
        <div className="marquee-track flex w-max">
          <Group />
          <Group dup />
        </div>
      </div>
    </div>
  );
}

const schools = [
  { name: "UC Berkeley Haas School of Business", src: haas, h: "h-4" },
  { name: "Georgia Institute of Technology", src: gt, h: "h-6" },
  { name: "UC Davis", src: ucd, h: "h-4" },
];

export function EducationLogos() {
  return (
    <div className="mt-3 w-full rounded-2xl border border-border bg-card p-3">
      <p id="edu-logos" className="mb-2 flex h-7 items-center text-xs text-muted-foreground">Education</p>
      <ul aria-labelledby="edu-logos" className="flex flex-wrap gap-3 lg:flex-nowrap lg:overflow-x-auto">
        {schools.map((s) => (
          <li key={s.name} className="flex h-10 shrink-0 items-center rounded-lg border border-border bg-logo-tile px-3">
            <img src={s.src} alt={s.name} className={`${s.h} w-auto`} />
          </li>
        ))}
      </ul>
    </div>
  );
}
