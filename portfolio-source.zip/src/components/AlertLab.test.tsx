import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";
import { AlertLab } from "./AlertLab";

afterEach(cleanup);

describe("Alert Lab keyboard navigation", () => {
  it("selects and focuses scenarios with arrow keys, wraps, and supports Home/End", () => {
    render(<AlertLab />);
    const noisy = screen.getByRole("radio", { name: "Noisy day" });
    const processor = screen.getByRole("radio", { name: "Processor degradation" });
    const low = screen.getByRole("radio", { name: "Low-volume dip" });
    noisy.focus();
    fireEvent.keyDown(noisy, { key: "ArrowRight" });
    expect(processor).toHaveAttribute("aria-checked", "true");
    expect(processor).toHaveFocus();
    expect(noisy).toHaveAttribute("tabindex", "-1");
    fireEvent.keyDown(processor, { key: "End" });
    expect(low).toHaveFocus();
    expect(low).toHaveAttribute("aria-checked", "true");
    fireEvent.keyDown(low, { key: "ArrowDown" });
    expect(noisy).toHaveFocus();
    fireEvent.keyDown(noisy, { key: "ArrowLeft" });
    expect(low).toHaveFocus();
    fireEvent.keyDown(low, { key: "Home" });
    expect(noisy).toHaveFocus();
    expect(noisy).toHaveAttribute("aria-checked", "true");
    expect(noisy).toHaveAttribute("tabindex", "0");
  });
});
