import type { ReactNode } from "react";
import { useId, useState } from "react";
import { ChevronDown } from "lucide-react";

const mono = { fontFamily: "var(--font-mono)" } as const;

export function RokuVisual() {
  const spark = [30, 34, 31, 38, 36, 42, 40, 45, 43, 48, 46, 50];
  const path = (off: number) =>
    spark.map((v, i) => `${i === 0 ? "M" : "L"}${10 + i * 9},${off - v * 0.45}`).join(" ");
  const regions = ["R1", "R2", "R3", "R4", "R5"];
  return (
    <svg viewBox="0 0 400 240" role="img" aria-labelledby="roku-t roku-d" className="h-auto w-full">
      <title id="roku-t">Illustrative payment monitoring dashboard</title>
      <desc id="roku-d">Schematic dashboard with authorization, tokenization and cost signal tiles, a five-region health grid and a detect, prioritize, escalate workflow. Sample data, not live.</desc>
      <rect width="400" height="240" rx="14" className="fill-ink" />
      <circle cx="20" cy="18" r="3" className="fill-primary" />
      <text x="30" y="21" fontSize="9" style={mono} className="fill-ink-foreground/70">PAYMENT HEALTH · SAMPLE DATA · NOT LIVE</text>
      {["Authorization", "Tokenization", "Cost"].map((l, k) => (
        <g key={l} transform={`translate(${14 + k * 126},34)`}>
          <rect width="118" height="78" rx="8" className="fill-ink-foreground/10" />
          <text x="10" y="18" fontSize="10" style={mono} className="fill-ink-foreground/80">{l}</text>
          <path data-chart-line d={path(70)} transform="translate(-2,0)" fill="none" strokeWidth="2" className={k === 0 ? "stroke-primary" : "stroke-ink-foreground/60"} />
        </g>
      ))}
      <text x="14" y="134" fontSize="9" style={mono} className="fill-ink-foreground/70">REGION HEALTH</text>
      {regions.map((r, i) => (
        <g key={r} transform={`translate(${14 + i * 40},142)`}>
          {[0, 1, 2].map((j) => (
            <rect key={j} y={j * 16} width="34" height="12" rx="3" className={i === 3 && j === 1 ? "fill-primary" : "fill-ink-foreground/20"} />
          ))}
          <text x="17" y="64" fontSize="9" textAnchor="middle" style={mono} className="fill-ink-foreground/70">{r}</text>
        </g>
      ))}
      {["Detect", "Prioritize", "Escalate"].map((s, i) => (
        <g key={s} transform={`translate(226,${140 + i * 28})`}>
          <rect width="160" height="22" rx="11" className={i === 0 ? "fill-primary" : "fill-ink-foreground/10"} />
          <text x="14" y="15" fontSize="10" style={mono} className={i === 0 ? "fill-primary-foreground" : "fill-ink-foreground"}>{`0${i + 1}  ${s}`}</text>
        </g>
      ))}
    </svg>
  );
}

function VisaVisual() {
  const bars = [44, 60, 78, 96];
  return (
    <svg data-sequence viewBox="0 0 400 240" role="img" aria-labelledby="visa-t visa-d" className="h-auto w-full">
      <title id="visa-t">Illustrative spreadsheet-to-insight workflow</title>
      <desc id="visa-d">A sample spreadsheet feeds an unnumbered four-year forecast bar chart, leading to a decision. Bars are illustrative, not actual forecast values.</desc>
      <rect width="400" height="240" rx="14" className="fill-card stroke-border" />
      <g transform="translate(16,24)">
        {Array.from({ length: 6 }).map((_, r) =>
          Array.from({ length: 3 }).map((_, c) => (
            <rect key={`${r}${c}`} x={c * 34} y={r * 18} width="32" height="16" className={r === 0 ? "fill-foreground/15" : "fill-muted stroke-border"} />
          )),
        )}
      </g>
      <path d="M126 78 H150" strokeWidth="2" className="stroke-primary" markerEnd="url(#arr)" />
      <defs>
        <marker id="arr" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto">
          <path d="M0 0 L10 5 L0 10z" className="fill-primary" />
        </marker>
      </defs>
      <g transform="translate(160,20)">
        <line x1="0" y1="116" x2="224" y2="116" className="stroke-foreground/30" />
        {bars.map((h, i) => (
          <g key={i}>
            <rect data-chart-bar x={12 + i * 54} y={116 - h} width="36" height={h} rx="4" className={i === 3 ? "fill-primary" : "fill-primary/35"} />
            <text x={30 + i * 54} y="132" fontSize="10" textAnchor="middle" style={mono} className="fill-muted-foreground">{`Y${i + 1}`}</text>
          </g>
        ))}
      </g>
      {["Reporting", "Analysis", "Decision"].map((s, i) => (
        <g key={s} data-stage={['0:1100', '1900:3100', '3900:5400'][i]} transform={`translate(${16 + i * 126},180)`}>
          <rect width="116" height="38" rx="10" className={i === 2 ? "fill-foreground" : "fill-accent"} />
          <text x="58" y="24" fontSize="12" textAnchor="middle" className={i === 2 ? "fill-background" : "fill-accent-foreground"}>{s}</text>
        </g>
      ))}
      <path data-trace data-path="1100:1900" d="M132 199 H142 V169 H200 V180" fill="none" strokeWidth="1.5" className="stroke-foreground/40" />
      <path data-trace data-path="3100:3900" d="M258 199 H264 V169 H326 V180" fill="none" strokeWidth="1.5" className="stroke-foreground/40" />
    </svg>
  );
}

function ChevronVisual() {
  return (
    <svg viewBox="0 0 400 220" role="img" aria-labelledby="chev-t chev-d" className="h-auto w-full">
      <title id="chev-t">Illustrative pipeline calculation dashboard</title>
      <desc id="chev-d">A pipeline schematic with nodes and segments, and relative calculation time bars: before at 100, after at 10, showing 90% less time.</desc>
      <rect width="400" height="220" rx="14" className="fill-card stroke-border" />
      <path d="M30 60 H140 L190 40 H290 L340 70 H370" fill="none" strokeWidth="4" strokeLinecap="round" className="stroke-foreground/25" />
      {[[30, 60], [140, 60], [190, 40], [290, 40], [340, 70], [370, 70]].map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r="6" strokeWidth="2" className={i === 3 ? "fill-primary stroke-primary" : "fill-card stroke-foreground/50"} />
      ))}
      <text x="30" y="110" fontSize="10" style={mono} className="fill-muted-foreground">RELATIVE CALCULATION TIME</text>
      <text x="30" y="138" fontSize="11" className="fill-foreground">Before</text>
      <rect data-chart-bar="x" x="90" y="127" width="280" height="14" rx="7" className="fill-foreground/25" />
      <text x="30" y="168" fontSize="11" className="fill-foreground">After</text>
      <rect data-chart-bar="x" x="90" y="157" width="28" height="14" rx="7" className="fill-primary" />
      <text x="128" y="168" fontSize="11" className="fill-primary">90% less time</text>
      <text x="370" y="200" fontSize="9" textAnchor="end" style={mono} className="fill-muted-foreground">Baseline 100 → 10</text>
    </svg>
  );
}

function EffectiveVisual() {
  const nodes = [
    { v: "3+", l: "markets analyzed" },
    { v: "50+", l: "prospects researched" },
    { v: "20+", l: "opportunities evaluated" },
  ];
  return (
    <svg data-sequence viewBox="0 0 400 220" role="img" aria-labelledby="eff-t eff-d" className="h-auto w-full">
      <title id="eff-t">Illustrative go-to-market research scope</title>
      <desc id="eff-d">Research inputs flow into an ideal customer profile, alongside three independent counts: 3+ markets analyzed, 50+ prospects researched, 20+ opportunities evaluated. Not a conversion funnel.</desc>
      <rect width="400" height="220" rx="14" className="fill-card stroke-border" />
      <text x="20" y="28" fontSize="10" style={mono} className="fill-muted-foreground">RESEARCH SCOPE · INDEPENDENT COUNTS</text>
      {nodes.map((n, i) => (
        <g key={n.l} transform={`translate(${20 + i * 124},46)`}>
          <g data-stage={`${i * 180}:${900 + i * 180}`}>
            <rect width="112" height="72" rx="12" className="fill-accent" />
            <text x="56" y="34" fontSize="22" textAnchor="middle" style={{ fontFamily: "var(--font-display)" }} className="fill-accent-foreground">{n.v}</text>
            <text x="56" y="56" fontSize="9.5" textAnchor="middle" className="fill-accent-foreground">{n.l}</text>
          </g>
          <path data-trace data-path={`${900 + i * 180}:${2100 + i * 180}`} d={`M56 72 C56 90, ${180 - i * 124} 86, ${180 - i * 124} 104`} fill="none" strokeDasharray="3 3" className="stroke-foreground/30" />
        </g>
      ))}
      <g data-stage="2400:3800">
        <rect x="130" y="150" width="140" height="44" rx="22" className="fill-foreground" />
        <text x="200" y="177" fontSize="12" textAnchor="middle" className="fill-background">ICP &amp; pipeline</text>
      </g>
    </svg>
  );
}

function PartnerVisual() {
  const lanes = [
    { l: "Product", x: 14 },
    { l: "Engineering", x: 140 },
    { l: "Payment partner", x: 266, sub: "Adyen · Fiserv" },
  ];
  const steps = ["Issue", "Shared diagnosis", "Fix & verify"];
  return (
    <svg data-sequence viewBox="0 0 400 240" role="img" aria-labelledby="psp-t psp-d" className="h-auto w-full">
      <title id="psp-t">Illustrative payment partner workflow</title>
      <desc id="psp-d">Product, engineering and payment partner lanes, with Adyen and Fiserv named as partners, hand off into a shared flow: issue, shared diagnosis, fix and verify, with a dotted loop back for validation and closure. Illustrative workflow.</desc>
      <defs>
        <marker id="psp-a" viewBox="0 0 6 6" refX="6" refY="3" markerWidth="6" markerHeight="6" markerUnits="userSpaceOnUse" orient="auto">
          <path d="M0 0 L6 3 L0 6z" className="fill-primary" />
        </marker>
      </defs>
      <rect width="400" height="240" rx="14" className="fill-card stroke-border" />
      {lanes.map((ln, i) => (
        <g key={ln.l} transform={`translate(${ln.x},16)`}>
          <rect width="120" height="52" rx="10" className={i === 2 ? "fill-accent" : "fill-muted"} />
          <text x="60" y={ln.sub ? 23 : 31} fontSize="13" fontWeight="600" textAnchor="middle" className={i === 2 ? "fill-accent-foreground" : "fill-foreground"}>{ln.l}</text>
          {ln.sub && <text x="60" y="41" fontSize="11.5" textAnchor="middle" className="fill-accent-foreground">{ln.sub}</text>}
          <path d="M60 52 V84" strokeWidth="1.5" strokeDasharray="3 3" className="stroke-foreground/40" />
        </g>
      ))}
      {steps.map((st, i) => (
        <g key={st} data-stage={['0:900', '1500:2500', '3100:4100'][i]} transform={`translate(${[14, 144, 278][i]},104)`}>
          <rect width={i === 1 ? 112 : 108} height="48" rx="24" className={i === 1 ? "fill-ink" : "fill-background stroke-primary"} strokeWidth="1.5" />
          <text x={i === 1 ? 56 : 54} y="29" fontSize="12.5" fontWeight="600" textAnchor="middle" className={i === 1 ? "fill-ink-foreground" : "fill-foreground"}>{st}</text>
        </g>
      ))}
      <path data-trace data-path="900:1500" d="M126 128 H140" strokeWidth="1.5" className="stroke-primary" markerEnd="url(#psp-a)" />
      <path data-trace data-path="2500:3100" d="M260 128 H274" strokeWidth="1.5" className="stroke-primary" markerEnd="url(#psp-a)" />
      <path data-trace data-path="4100:5000" d="M332 158 V196 Q332 210 318 210 H262" fill="none" strokeWidth="1.5" strokeDasharray="5 4" className="stroke-primary" />
      <path data-trace data-path="5800:7000" d="M138 210 H82 Q68 210 68 196 V160" fill="none" strokeWidth="1.5" strokeDasharray="5 4" className="stroke-primary" markerEnd="url(#psp-a)" />
      <g data-stage="5000:5800">
        <rect x="138" y="198" width="124" height="24" rx="12" className="fill-card stroke-border" />
        <text x="200" y="214" fontSize="12" textAnchor="middle" className="fill-foreground">Validate &amp; close</text>
      </g>
    </svg>
  );
}

type Feature = {
  org: string;
  title: string;
  summary: string;
  points: string[];
  note?: string;
  more?: string[];
  label: string;
  visual: ReactNode;
};

const features: Feature[] = [
  {
    org: "Roku / Partner operations",
    title: "Closing the loop with payment partners",
    summary: "Coordinated with Adyen, Fiserv, and internal product and engineering teams to investigate payment anomalies, align on fixes, and follow issues through resolution.",
    note: "From authorization and tokenization issues to statement descriptors and recovery workflows.",
    points: ["PSP coordination", "Root-cause analysis", "Escalation & follow-through"],
    label: "Illustrative partner workflow",
    visual: <PartnerVisual />,
  },
  {
    org: "Visa",
    title: "Forecasting, automation & Tap to Pay",
    summary: "Built a CEO-recognized $1B four-year dispute revenue forecast (a forecast, not realized revenue), made KPI reporting 90% faster, and supported Tap to Pay rollout on POS terminals with NFL and MLB.",
    points: ["4-year forecast", "$1B forecast scope", "2,500+ terminals"],
    more: [
      "Pricing analysis with SQL and Excel informed strategies that brought $150M in Annualized Adjusted Net Revenue.",
      "Merchant compliance work led to a 20% increase in Tap to Pay revenue.",
      "Automated business cases supporting more than $5M in revenue.",
      "Also introduced monthly reporting on electric-vehicle charging payments.",
    ],
    label: "Illustrative workflow · bars not actual values",
    visual: <VisaVisual />,
  },
  {
    org: "Chevron",
    title: "Operational dashboards",
    summary: "Built a Power BI gas pipeline calculation dashboard and the RateIT dashboard.",
    points: ["90% less calculation time", "RateIT used by 40+ Product Owners"],
    label: "Illustrative preview · not the actual dashboard",
    visual: <ChevronVisual />,
  },
  {
    org: "Effective AI",
    title: "Go-to-market research",
    summary: "Worked with the founders to research prospects and markets and evaluate opportunities.",
    points: ["3+ markets analyzed", "50+ prospects researched · 20+ opportunities evaluated"],
    label: "Illustrative workflow",
    visual: <EffectiveVisual />,
  },
];

export function WorkFeatures() {
  return (
    <div className="grid gap-6 md:grid-cols-2">
      {features.map((f, i) => (
        <article key={f.org} className="card-lift flex min-w-0 flex-col overflow-hidden rounded-2xl border border-border bg-card">
          <figure className={`viz ${["surface-light", "surface-slate", "surface-ink", "surface-warm"][i]} bg-fine-grid border-b border-border p-4 sm:p-6`}>
            {f.visual}
            <figcaption className="mt-3 text-xs leading-snug text-muted-foreground">{f.label}</figcaption>
          </figure>
          <div className="flex flex-1 flex-col p-6 sm:p-8">
            <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{f.org}</p>
            <h3 className="mt-2 font-display text-2xl">{f.title}</h3>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{f.summary}</p>
            {f.note && <p className="mt-3 border-l-2 border-primary pl-3 text-sm leading-relaxed text-foreground">{f.note}</p>}
            <ul className="mt-5 flex flex-wrap gap-2">
              {f.points.map((p) => (
                <li key={p} className="rounded-full border border-border bg-background px-3 py-1 text-xs">{p}</li>
              ))}
            </ul>
            {f.more && <MoreImpact items={f.more} />}
          </div>
        </article>
      ))}
    </div>
  );
}

function MoreImpact({ items }: { items: string[] }) {
  const [open, setOpen] = useState(false);
  const id = useId();
  return (
    <div className="mt-5 border-t border-border pt-4">
      <button type="button" aria-expanded={open} aria-controls={id} onClick={() => setOpen(!open)} className="inline-flex min-h-11 items-center gap-2 text-sm font-medium text-foreground hover:text-primary">
        <ChevronDown size={16} aria-hidden="true" className={`transition-transform ${open ? "rotate-180" : ""}`} />
        {open ? "Hide more impact" : "More impact"}
      </button>
      <ul id={id} hidden={!open} className="mt-2 list-disc space-y-2 pl-5 text-sm leading-relaxed text-muted-foreground">
        {items.map((t) => <li key={t}>{t}</li>)}
      </ul>
    </div>
  );
}
