import { act, cleanup, renderHook } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { useDiagramMotion } from "./use-diagram-motion";

describe("visible workflow lifecycle", () => {
  let observe: IntersectionObserverCallback;
  let media: EventTarget & { matches: boolean };
  let hidden: boolean;
  let animate: ReturnType<typeof vi.fn>;
  const visible = (value: boolean) => {
    const target = document.querySelector("ol, svg");
    if (!target) throw new Error("Missing diagram fixture");
    act(() => observe([
      { target, isIntersecting: value, intersectionRatio: value ? 1 : 0, boundingClientRect: target.getBoundingClientRect(), intersectionRect: target.getBoundingClientRect(), rootBounds: null, time: 0 },
    ], {} as IntersectionObserver));
  };
  const advance = (ms: number) => act(() => vi.advanceTimersByTime(ms));

  beforeEach(() => {
    vi.useFakeTimers();
    hidden = false;
    vi.spyOn(document, "hidden", "get").mockImplementation(() => hidden);
    media = Object.assign(new EventTarget(), { matches: false });
    vi.stubGlobal("matchMedia", () => media);
    vi.stubGlobal("SVGPathElement", class {});
    vi.stubGlobal("SVGGraphicsElement", class {});
    vi.stubGlobal("IntersectionObserver", class {
      constructor(callback: IntersectionObserverCallback) { observe = callback; }
      observe() {}
      disconnect() {}
    });
    document.body.innerHTML = '<ol><li><span data-trace-html></span></li></ol>';
    vi.spyOn(Element.prototype, "getBoundingClientRect").mockReturnValue({ width: 20, height: 1 } as DOMRect);
    animate = vi.fn((_frames: Keyframe[], _options: KeyframeAnimationOptions) => {
      const animation = { onfinish: null as (() => void) | null, oncancel: null as (() => void) | null, cancel: () => {} };
      const timer = setTimeout(() => animation.onfinish?.(), 1200);
      animation.cancel = () => { clearTimeout(timer); animation.oncancel?.(); };
      return animation;
    });
    vi.stubGlobal("Animation", class {});
    Object.defineProperty(Element.prototype, "animate", { value: animate, configurable: true });
  });
  afterEach(() => { cleanup(); vi.clearAllTimers(); vi.useRealTimers(); vi.restoreAllMocks(); vi.unstubAllGlobals(); });

  it("travels for 1200ms twice on a 7600ms cycle without duplicate dots", () => {
    renderHook(() => useDiagramMotion()); visible(true);
    advance(900);
    expect(animate).toHaveBeenCalledTimes(1);
    expect(animate.mock.calls[0]?.[1]).toMatchObject({ duration: 1200 });
    expect(document.querySelectorAll("[data-workflow-dot]")).toHaveLength(1);
    advance(1200);
    expect(document.querySelectorAll("[data-workflow-dot]")).toHaveLength(0);
    advance(6400);
    expect(animate).toHaveBeenCalledTimes(2);
    expect(document.querySelectorAll("[data-workflow-dot]")).toHaveLength(1);
  });
  it("removes active traces and every scheduled timer offscreen and on unmount", () => {
    const { unmount } = renderHook(() => useDiagramMotion()); visible(true); advance(900);
    visible(false);
    expect(document.querySelectorAll("[data-workflow-dot]")).toHaveLength(0);
    expect(vi.getTimerCount()).toBe(0);
    advance(20000); expect(animate).toHaveBeenCalledTimes(1);
    visible(true); advance(900); unmount();
    expect(vi.getTimerCount()).toBe(0);
    expect(document.querySelectorAll("[data-workflow-dot]")).toHaveLength(0);
  });
  it("stops instantly for reduced motion and background tabs, resuming with a pause", () => {
    renderHook(() => useDiagramMotion()); visible(true); advance(900);
    act(() => { media.matches = true; media.dispatchEvent(new Event("change")); });
    expect(vi.getTimerCount()).toBe(0);
    expect(document.querySelectorAll("[data-workflow-dot]")).toHaveLength(0);
    act(() => { media.matches = false; media.dispatchEvent(new Event("change")); });
    advance(899); expect(animate).toHaveBeenCalledTimes(1);
    advance(1); expect(animate).toHaveBeenCalledTimes(2);
    act(() => { hidden = true; document.dispatchEvent(new Event("visibilitychange")); });
    expect(vi.getTimerCount()).toBe(0);
    expect(document.querySelectorAll("[data-workflow-dot]")).toHaveLength(0);
    act(() => { hidden = false; document.dispatchEvent(new Event("visibilitychange")); });
    advance(900); expect(animate).toHaveBeenCalledTimes(3);
  });
  it("pauses independently through the shared control", () => {
    const { result } = renderHook(() => useDiagramMotion()); visible(true); advance(900);
    act(() => result.current.togglePaused());
    expect(result.current.paused).toBe(true);
    expect(vi.getTimerCount()).toBe(0);
    expect(document.querySelectorAll("[data-workflow-dot]")).toHaveLength(0);
    advance(20000); expect(animate).toHaveBeenCalledTimes(1);
    act(() => result.current.togglePaused()); advance(900);
    expect(animate).toHaveBeenCalledTimes(2);
  });
  it("never replays chart entrances on return scroll or a motion preference change", () => {
    vi.stubGlobal("SVGPathElement", SVGElement);
    document.body.innerHTML = '<svg><path data-chart-line /></svg>';
    const path = document.querySelector("path");
    if (!path) throw new Error("Missing chart fixture");
    Object.assign(path, { getTotalLength: () => 100 });
    renderHook(() => useDiagramMotion()); visible(true);
    expect(animate).toHaveBeenCalledTimes(1);
    advance(1200); visible(false); visible(true);
    act(() => { media.matches = true; media.dispatchEvent(new Event("change")); media.matches = false; media.dispatchEvent(new Event("change")); });
    advance(10000);
    expect(animate).toHaveBeenCalledTimes(1);
  });
  it("uses declarative stage order and path timing on a nine-second cycle, restoring styles on pause", () => {
    document.body.innerHTML = '<ol data-sequence><span data-stage="0:850">Detect</span><span data-stage="1350:2200">Probe</span><span data-trace-html data-path="850:1350"></span></ol>';
    const { result } = renderHook(() => useDiagramMotion()); visible(true); advance(900);
    expect(animate).toHaveBeenCalledTimes(3);
    expect(animate.mock.calls[0]?.[1]).toMatchObject({ duration: 9000 });
    expect(animate.mock.calls[1]?.[0][1].offset).toBe(1350 / 9000);
    expect(animate.mock.calls[2]?.[1]).toMatchObject({ duration: 500, delay: 850 });
    advance(9000);
    expect(animate).toHaveBeenCalledTimes(6);
    act(() => result.current.togglePaused());
    expect(vi.getTimerCount()).toBe(0);
    expect(document.querySelectorAll('[data-workflow-dot]')).toHaveLength(0);
    expect(document.querySelector('[data-stage]')?.getAttribute('style')).toBe(null);
  });
});