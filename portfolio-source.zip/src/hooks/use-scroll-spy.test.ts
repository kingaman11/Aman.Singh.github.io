import { describe, expect, it } from "vitest";
import { activeHref } from "./use-scroll-spy";

// tops order: work, projects, more-work, experience, expertise, about, recommendations, contact
const tops = (passed: number) => Array.from({ length: 8 }, (_, i) => (i < passed ? -100 : 900));

describe("scroll spy mapping", () => {
  it("nothing active in the hero", () => expect(activeHref(tops(0), false)).toBeNull());
  it("Work while on the section intro", () => expect(activeHref(tops(1), false)).toBe("#work"));
  it("Projects through featured stories and Alert Lab", () => expect(activeHref(tops(2), false)).toBe("#projects"));
  it("Work from More selected work", () => expect(activeHref(tops(3), false)).toBe("#work"));
  it("Expertise wins inside Experience", () => expect(activeHref(tops(5), false)).toBe("#expertise"));
  it("Contact at page bottom", () => expect(activeHref(tops(6), true)).toBe("#contact"));
});
