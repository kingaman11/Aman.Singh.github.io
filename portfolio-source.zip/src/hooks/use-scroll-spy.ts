import { useEffect, useState } from "react";

/**
 * Ordered anchors → nav href. The active item is the last anchor whose top has
 * passed just below the sticky header. Nested anchors (projects inside work,
 * expertise inside experience) come later in the list so they win while in view.
 */
export const SPY_ANCHORS: [id: string, href: string][] = [
  ["work", "#work"],
  ["projects", "#projects"],
  ["more-work", "#work"],
  ["experience", "#experience"],
  ["expertise", "#expertise"],
  ["about", "#about"],
  ["recommendations", "#recommendations"],
  ["contact", "#contact"],
];
const LINE = 96; // px from viewport top (header is 64px)

export function activeHref(tops: number[], atBottom: boolean): string | null {
  if (atBottom) return SPY_ANCHORS[SPY_ANCHORS.length - 1]![1];
  let hit: string | null = null;
  tops.forEach((t, i) => { if (t <= LINE) hit = SPY_ANCHORS[i]![1]; });
  return hit;
}

/** Layout position ignoring CSS transforms (reveal offsets must not shift the spy). */
function docTop(el: HTMLElement | null): number {
  if (!el) return Infinity;
  let y = 0;
  for (let n: HTMLElement | null = el; n; n = n.offsetParent as HTMLElement | null) y += n.offsetTop;
  return y;
}

export function useScrollSpy() {
  const [active, setActive] = useState<string | null>(null);
  useEffect(() => {
    let raf = 0;
    const calc = () => {
      raf = 0;
      const tops = SPY_ANCHORS.map(([id]) => docTop(document.getElementById(id)) - window.scrollY);
      const atBottom = window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 4;
      setActive(activeHref(tops, atBottom));
    };
    const onScroll = () => { if (!raf) raf = requestAnimationFrame(calc); };
    calc();
    // Layout can shift without scrolling (fonts, images, reveals, expanders, hash jump on load).
    const ro = new ResizeObserver(onScroll);
    ro.observe(document.body);
    document.fonts?.ready.then(onScroll);
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    window.addEventListener("hashchange", onScroll);
    window.addEventListener("load", onScroll);
    return () => {
      ro.disconnect();
      window.removeEventListener("scroll", onScroll); window.removeEventListener("resize", onScroll);
      window.removeEventListener("hashchange", onScroll); window.removeEventListener("load", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);
  return active;
}
