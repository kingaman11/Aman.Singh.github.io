import { useEffect } from "react";

/** Align entry links after fonts settle, without moving a visitor who has started interacting. */
export function useInitialAnchor() {
  useEffect(() => {
    const hash = window.location.hash;
    if (!hash || hash === "#") return;
    const navigation = performance.getEntriesByType("navigation")[0] as PerformanceNavigationTiming | undefined;
    if (navigation?.type === "back_forward") return;
    let cancelled = false;
    let firstFrame = 0;
    let secondFrame = 0;
    const cancel = () => { cancelled = true; };
    const events = ["wheel", "touchstart", "pointerdown", "keydown"] as const;
    events.forEach((event) => window.addEventListener(event, cancel, { passive: true, once: true }));
    (document.fonts?.ready ?? Promise.resolve()).then(() => {
      firstFrame = requestAnimationFrame(() => {
        secondFrame = requestAnimationFrame(() => {
          if (cancelled || window.location.hash !== hash) return;
          let id: string;
          try { id = decodeURIComponent(hash.slice(1)); } catch { return; }
          const target = document.getElementById(id);
          if (!target) return;
          let top = 0;
          for (let node: HTMLElement | null = target; node; node = node.offsetParent as HTMLElement | null) top += node.offsetTop;
          const margin = parseFloat(getComputedStyle(target).scrollMarginTop) || 0;
          window.scrollTo({ top: Math.max(0, top - margin), behavior: "instant" });
        });
      });
    });
    return () => {
      cancelled = true;
      cancelAnimationFrame(firstFrame);
      cancelAnimationFrame(secondFrame);
      events.forEach((event) => window.removeEventListener(event, cancel));
    };
  }, []);
}
