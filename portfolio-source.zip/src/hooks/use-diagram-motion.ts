import { useEffect, useRef, useState } from "react";
import { sequenceWindow, WORKFLOW_CYCLE } from "@/lib/workflow-sequence";

const SEL = "[data-trace],[data-chart-line],[data-chart-bar],[data-trace-html]";
const EASE = "cubic-bezier(.4,0,.2,1)";
type Owner = {
  element: Element;
  index: number;
  visible: boolean;
  entered: boolean;
  timer: ReturnType<typeof setTimeout> | undefined;
  traces: Set<Animation>;
  charts: Set<Animation>;
  dots: Set<Element>;
};

/** Final artwork is always visible. Only connector dots repeat; charts enter once. */
export function useDiagramMotion() {
  const [paused, setPaused] = useState(false);
  const controller = useRef<((paused: boolean) => void) | null>(null);

  useEffect(() => {
    if (!("IntersectionObserver" in window) || !Element.prototype.animate) return;
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    let manuallyPaused = false;
    let disposed = false;
    const elements = new Set<Element>();
    document.querySelectorAll(SEL).forEach((t) => elements.add(t.closest("svg") ?? t.closest("ol") ?? t));
    const owners: Owner[] = [...elements].map((element, index) => ({
      element, index, visible: false, entered: false, timer: undefined,
      traces: new Set(), charts: new Set(), dots: new Set(),
    }));
    const byElement = new Map(owners.map((owner) => [owner.element, owner]));
    const targets = (owner: Owner) => owner.element.matches(SEL) ? [owner.element] : [...owner.element.querySelectorAll(SEL)];
    const allowed = (owner: Owner) => !disposed && owner.visible && !document.hidden && !mq.matches && !manuallyPaused;

    const track = (owner: Owner, animation: Animation, dot?: Element, workflow = false) => {
      const animations = dot || workflow ? owner.traces : owner.charts;
      animations.add(animation);
      if (dot) owner.dots.add(dot);
      animation.onfinish = animation.oncancel = () => {
        animations.delete(animation);
        dot?.remove();
        if (dot) owner.dots.delete(dot);
      };
    };
    const stopTraces = (owner: Owner) => {
      clearTimeout(owner.timer);
      owner.timer = undefined;
      [...owner.traces].forEach((animation) => animation.cancel());
      owner.traces.clear();
      owner.dots.forEach((dot) => dot.remove());
      owner.dots.clear();
    };
    const stopCharts = (owner: Owner) => {
      [...owner.charts].forEach((animation) => animation.cancel());
      owner.charts.clear();
    };

    const enterCharts = (owner: Owner) => {
      if (owner.entered || !owner.visible || document.hidden) return;
      // Reduced motion consumes the entrance, so enabling motion never redraws it.
      owner.entered = true;
      if (mq.matches) return;
      for (const t of targets(owner)) {
        if (t instanceof SVGPathElement && t.hasAttribute("data-chart-line")) {
          const len = t.getTotalLength();
          track(owner, t.animate([{ strokeDasharray: `${len} ${len}`, strokeDashoffset: len }, { strokeDasharray: `${len} ${len}`, strokeDashoffset: 0 }], { duration: 750, easing: EASE }));
        } else if (t instanceof SVGGraphicsElement && t.hasAttribute("data-chart-bar")) {
          const horiz = t.getAttribute("data-chart-bar") === "x";
          t.style.transformBox = "fill-box";
          t.style.transformOrigin = horiz ? "left center" : "center bottom";
          track(owner, t.animate([{ transform: horiz ? "scaleX(0)" : "scaleY(0)" }, { transform: "none" }], { duration: 650, easing: EASE }));
        }
      }
    };

    const pass = (owner: Owner) => {
      owner.timer = undefined;
      if (!allowed(owner)) return;
      const sequenced = owner.element.hasAttribute("data-sequence");
      if (sequenced) {
        owner.element.querySelectorAll("[data-stage]").forEach((stage) => {
          const timing = sequenceWindow(stage.getAttribute("data-stage"));
          if (!timing) return;
          const [start, end] = timing;
          const parts = stage.matches("rect,circle,text,span") ? [stage] : [...stage.querySelectorAll("rect,circle,text,[data-stage-fill]")];
          parts.forEach((part) => {
            const styles = getComputedStyle(part);
            const html = part instanceof HTMLElement;
            const text = part.matches("text") || html;
            const property = html ? "backgroundColor" : "fill";
            const base = html ? styles.backgroundColor : styles.fill;
            const active = styles.getPropertyValue(text && !html ? "--signal-foreground" : "--primary").trim();
            const frames: Keyframe[] = [{ [property]: base, offset: 0 }, { [property]: base, offset: start / WORKFLOW_CYCLE }, { [property]: active, offset: (start + 90) / WORKFLOW_CYCLE }, { [property]: active, offset: (end - 90) / WORKFLOW_CYCLE }, { [property]: base, offset: end / WORKFLOW_CYCLE }, { [property]: base, offset: 1 }];
            if (html) frames.forEach((frame) => { frame['color'] = frame[property] === base ? styles.color : styles.getPropertyValue("--signal-foreground").trim(); });
            track(owner, part.animate(frames, { duration: WORKFLOW_CYCLE, easing: "linear" }), undefined, true);
          });
        });
      }
      let sequence = 0;
      for (const t of targets(owner)) {
        const timing = sequenceWindow(t.getAttribute("data-path"));
        if (sequenced && !timing) continue;
        let dot: Element;
        let frames: Keyframe[];
        if (t instanceof SVGPathElement && t.hasAttribute("data-trace")) {
          const len = t.getTotalLength();
          if (!len) continue;
          dot = document.createElementNS("http://www.w3.org/2000/svg", "circle");
          dot.setAttribute("r", "3.5");
          dot.setAttribute("class", "fill-primary");
          t.parentNode?.appendChild(dot);
          frames = Array.from({ length: 25 }, (_, k) => {
            const offset = k / 24;
            const p = t.getPointAtLength(offset * len);
            return { offset, transform: `translate(${p.x}px, ${p.y}px)`, opacity: offset < 0.1 ? offset * 10 : offset > 0.9 ? (1 - offset) * 10 : 1 };
          });
        } else if (t instanceof HTMLElement && t.hasAttribute("data-trace-html")) {
          const r = t.getBoundingClientRect();
          if (!r.width && !r.height) continue;
          const vertical = r.height >= r.width;
          dot = document.createElement("span");
          dot.className = "trace-dot";
          t.appendChild(dot);
          const end = vertical ? `translate(-3px, ${r.height - 3.5}px)` : `translate(${r.width - 3.5}px, -3px)`;
          const start = vertical ? "translate(-3px, -3.5px)" : "translate(-3.5px, -3px)";
          frames = [{ transform: start, opacity: 0 }, { opacity: 1, offset: 0.15 }, { opacity: 1, offset: 0.85 }, { transform: end, opacity: 0 }];
        } else continue;
        dot.setAttribute("aria-hidden", "true");
        dot.setAttribute("data-workflow-dot", "");
        (dot as HTMLElement | SVGElement).style.pointerEvents = "none";
        track(owner, dot.animate(frames, { duration: timing ? timing[1] - timing[0] : 1200, delay: timing ? timing[0] : sequence * 180, easing: "ease-in-out", fill: "both" }), dot);
        sequence++;
      }
      // One timer per visible diagram, with an intentionally quiet interval.
      if (sequence) owner.timer = setTimeout(() => pass(owner), sequenced ? WORKFLOW_CYCLE : 7600 + (owner.index % 4) * 400);
    };
    const resume = (owner: Owner) => {
      if (!allowed(owner) || owner.timer !== undefined || owner.traces.size) return;
      if (!targets(owner).some((t) => t.hasAttribute("data-trace") || t.hasAttribute("data-trace-html"))) return;
      owner.timer = setTimeout(() => pass(owner), 900 + (owner.index % 5) * 260);
    };
    const refresh = () => {
      owners.forEach((owner) => {
        if (!allowed(owner)) stopTraces(owner);
        else resume(owner);
        if (mq.matches || document.hidden || !owner.visible) stopCharts(owner);
        enterCharts(owner);
      });
    };
    const io = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        const owner = byElement.get(entry.target);
        if (!owner) continue;
        owner.visible = entry.isIntersecting && entry.intersectionRatio >= 0.15;
      }
      refresh();
    }, { threshold: [0, 0.15] });
    owners.forEach((owner) => io.observe(owner.element));
    controller.current = (value) => { manuallyPaused = value; refresh(); };
    mq.addEventListener("change", refresh);
    document.addEventListener("visibilitychange", refresh);
    return () => {
      disposed = true;
      controller.current = null;
      io.disconnect();
      mq.removeEventListener("change", refresh);
      document.removeEventListener("visibilitychange", refresh);
      owners.forEach((owner) => { stopTraces(owner); stopCharts(owner); });
    };
  }, []);

  useEffect(() => { controller.current?.(paused); }, [paused]);
  return { paused, togglePaused: () => setPaused((value) => !value) };
}