import { describe, expect, it } from "vitest";
import { sequenceWindow, WORKFLOW_CYCLE } from "./workflow-sequence";

describe("workflow timing", () => {
  it("reserves a quiet pause within a nine-second cycle", () => {
    expect(WORKFLOW_CYCLE).toBe(9000);
    expect(sequenceWindow("7100:8000")).toEqual([7100, 8000]);
    expect(sequenceWindow("8000:9000")).toBe(null);
  });
  it("rejects invalid or reversed windows", () => {
    for (const value of [null, "bad", "-1:200", "200:100", "0:0"]) expect(sequenceWindow(value)).toBe(null);
  });
});