/**
 * Alert Lab — browser-only, deterministic model.
 * Synthetic payment data; the "AI-assisted" view is a rule-based simulation of a
 * context layer (volume, persistence, grouping). Ground-truth labels are used ONLY
 * by `evaluate`, never by `thresholdAlerts` or `contextualTriage`.
 */

export type Sample = { t: number; rate: number; volume: number };
export type Labeled = Sample & { incident: boolean };
export type ScenarioId = "noisy" | "processor" | "lowvolume";
export type Settings = { threshold: number; persistence: number; minVolume: number };

export const STEP_MIN = 15;
export const SAMPLES = 96; // 24h
export const DEDUP_GAP = 1; // a confirmed breach within 1 quiet sample joins the open notification
export const DEFAULT_SETTINGS: Settings = { threshold: 96, persistence: 2, minVolume: 500 };

export const SCENARIOS: { id: ScenarioId; label: string; blurb: string }[] = [
  { id: "noisy", label: "Noisy day", blurb: "Frequent one-off dips around a single sustained incident." },
  { id: "processor", label: "Processor degradation", blurb: "Processor B degrades gradually through midday." },
  { id: "lowvolume", label: "Low-volume dip", blurb: "Overnight low traffic makes rates jumpy; one short daytime incident." },
];

export const fmtTime = (t: number) =>
  `${String(Math.floor(t / 60) % 24).padStart(2, "0")}:${String(t % 60).padStart(2, "0")}`;

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let r = Math.imul(a ^ (a >>> 15), 1 | a);
    r = (r + Math.imul(r ^ (r >>> 7), 61 | r)) ^ r;
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

const round = (n: number, d = 1) => Math.round(n * 10 ** d) / 10 ** d;

function dailyVolume(i: number, r: () => number, night = 0.18) {
  const h = (i * STEP_MIN) / 60;
  const shape = h < 6 ? night : h < 9 ? night + ((h - 6) / 3) * (1 - night) : h < 21 ? 1 : 1 - ((h - 21) / 3) * (1 - night);
  return Math.round(2400 * shape * (0.9 + r() * 0.2));
}

const cache = new Map<ScenarioId, Labeled[]>();

export function getScenario(id: ScenarioId): Labeled[] {
  const hit = cache.get(id);
  if (hit) return hit;
  const seed = { noisy: 11, processor: 23, lowvolume: 37 }[id];
  const r = rng(seed);
  const out: Labeled[] = [];
  for (let i = 0; i < SAMPLES; i++) {
    const volume = dailyVolume(i, r, id === "lowvolume" ? 0.08 : 0.18);
    // Smaller samples are noisier.
    const noise = (r() - 0.5) * (volume < 400 ? 4.5 : 1.1);
    let rate = 97.6 + noise;
    let incident = false;
    if (id === "noisy") {
      if ([14, 29, 41, 58, 71, 83].includes(i)) rate -= 2.6 + r() * 1.2; // one-off blips
      if (i >= 62 && i <= 69) { rate -= 4 + r(); incident = true; }
    } else if (id === "processor") {
      if (i >= 40 && i <= 56) {
        const k = i <= 48 ? (i - 40) / 8 : (56 - i) / 8;
        rate -= 1 + k * 5.5;
        incident = true;
      }
      if ([20, 77].includes(i)) rate -= 2.4;
    } else {
      if (i >= 10 && i <= 18 && i % 3 === 0) rate -= 3.5; // low-volume jitter
      if (i >= 50 && i <= 52) { rate -= 3.6; incident = true; }
    }
    out.push({ t: i * STEP_MIN, rate: round(Math.min(rate, 99.9)), volume, incident });
  }
  cache.set(id, out);
  return out;
}

/* ---------- Before: threshold alerting ---------- */
export function thresholdAlerts(data: Sample[], s: Pick<Settings, "threshold">): number[] {
  return data.flatMap((d, i) => (d.rate < s.threshold ? [i] : []));
}

/* ---------- After: simulated AI-assisted triage (causal rules) ---------- */
export type Disposition = "low-volume" | "held" | "notified" | "grouped";
export type Notification = { start: number; samples: number[]; minRate: number; explanation: string };
export type Triage = { dispositions: Map<number, Disposition>; notifications: Notification[]; raw: number; lowVolume: number; held: number; grouped: number; candidates: number };

export function contextualTriage(data: Sample[], s: Settings): Triage {
  const dispositions = new Map<number, Disposition>();
  const notifications: Notification[] = [];
  let run = 0; // consecutive qualified candidates ending at i (past + current only)
  let open: Notification | null = null;
  let lastConfirmed = -Infinity;
  let raw = 0, lowVolume = 0, held = 0, grouped = 0, candidates = 0;

  for (let i = 0; i < data.length; i++) {
    const d = data[i]!;
    const breach = d.rate < s.threshold;
    if (!breach) { run = 0; continue; }
    raw++;
    if (d.volume < s.minVolume) {
      dispositions.set(i, "low-volume"); lowVolume++; run = 0; continue;
    }
    candidates++;
    run++;
    if (run < s.persistence) { dispositions.set(i, "held"); held++; continue; }
    if (open && i - lastConfirmed <= DEDUP_GAP + 1) {
      open.samples.push(i); open.minRate = Math.min(open.minRate, d.rate);
      dispositions.set(i, "grouped"); grouped++;
    } else {
      open = { start: i, samples: [i], minRate: d.rate, explanation: "" };
      notifications.push(open);
      dispositions.set(i, "notified");
    }
    lastConfirmed = i;
  }
  for (const n of notifications) n.explanation = explain(data, n, s);
  return { dispositions, notifications, raw, lowVolume, held, grouped, candidates };
}

function explain(data: Sample[], n: Notification, s: Settings) {
  const d = data[n.start]!;
  const vol = d.volume.toLocaleString("en-US");
  const persist = s.persistence > 1 ? `held for ${s.persistence} consecutive samples` : "breach on a single sample";
  const grouped = n.samples.length > 1 ? ` Grouped ${n.samples.length - 1} follow-on breach${n.samples.length > 2 ? "es" : ""} (low ${n.minRate}%).` : "";
  return `${d.rate}% < ${s.threshold}% on ${vol} txns; ${persist}.${grouped}`;
}

/* ---------- Evaluation (uses hidden labels) ---------- */
export type Episode = { start: number; end: number };
export function episodes(data: Labeled[]): Episode[] {
  const eps: Episode[] = [];
  data.forEach((d, i) => {
    if (!d.incident) return;
    const last = eps[eps.length - 1];
    if (last && last.end === i - 1) last.end = i; else eps.push({ start: i, end: i });
  });
  return eps;
}

export type Score = { alerts: number; detected: number; total: number; missed: number; falseAlerts: number; delays: (number | null)[] };

function score(alertSamples: number[][], eps: Episode[]): Score {
  const inEp = (i: number) => eps.some((e) => i >= e.start && i <= e.end);
  const delays = eps.map((e) => {
    const first = alertSamples.flat().filter((i) => i >= e.start && i <= e.end).sort((a, b) => a - b)[0];
    return first === undefined ? null : (first - e.start) * STEP_MIN;
  });
  const detected = delays.filter((d) => d !== null).length;
  return { alerts: alertSamples.length, detected, total: eps.length, missed: eps.length - detected, falseAlerts: alertSamples.filter((g) => !g.some(inEp)).length, delays };
}

export function evaluate(data: Labeled[], s: Settings) {
  const eps = episodes(data);
  const base = thresholdAlerts(data, s);
  const tri = contextualTriage(data, s);
  const before = score(base.map((i) => [i]), eps);
  const after = score(tri.notifications.map((n) => n.samples), eps);
  const reduction = base.length === 0 ? null : Math.round((1 - tri.notifications.length / base.length) * 100);
  return { eps, base, tri, before, after, reduction };
}
