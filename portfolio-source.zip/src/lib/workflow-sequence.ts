/** Declarative millisecond windows within the shared nine-second workflow cycle. */
export const WORKFLOW_CYCLE = 9000;
export function sequenceWindow(value: string | null): [number, number] | null {
  if (!value) return null;
  const [start, end] = value.split(":").map(Number);
  if (start === undefined || end === undefined || !Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end <= start || end > WORKFLOW_CYCLE - 1000) return null;
  return [start, end];
}