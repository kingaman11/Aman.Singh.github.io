import { describe, expect, it } from "vitest";
import { contextualTriage, evaluate, getScenario, thresholdAlerts, type Labeled, SCENARIOS, DEFAULT_SETTINGS } from "./alert-lab";

const mk = (rates: number[], vol = 1000, inc: number[] = []): Labeled[] =>
  rates.map((rate, i) => ({ t: i * 15, rate, volume: vol, incident: inc.includes(i) }));

describe("alert lab model", () => {
  it("threshold boundary: equal to threshold is not a breach", () => {
    expect(thresholdAlerts(mk([96, 95.9, 96.1]), { threshold: 96 })).toEqual([1]);
  });

  it("persistence is causal: notifies on the Nth consecutive breach, never earlier", () => {
    const t = contextualTriage(mk([99, 90, 90, 90, 99]), { threshold: 96, persistence: 3, minVolume: 0 });
    expect(t.notifications.map((n) => n.start)).toEqual([3]);
    expect(t.held).toBe(2);
  });

  it("persistence does not look ahead: a breach followed by recovery stays held", () => {
    const t = contextualTriage(mk([90, 99, 99]), { threshold: 96, persistence: 2, minVolume: 0 });
    expect(t.notifications).toHaveLength(0);
  });

  it("filters low-volume breaches", () => {
    const d = mk([90, 90]).map((x, i) => ({ ...x, volume: i === 0 ? 100 : 1000 }));
    const t = contextualTriage(d, { threshold: 96, persistence: 1, minVolume: 500 });
    expect(t.lowVolume).toBe(1);
    expect(t.notifications.map((n) => n.start)).toEqual([1]);
  });

  it("groups contiguous confirmed breaches into one notification", () => {
    const t = contextualTriage(mk([90, 90, 90, 90]), { threshold: 96, persistence: 1, minVolume: 0 });
    expect(t.notifications).toHaveLength(1);
    expect(t.grouped).toBe(3);
  });

  it("scores episodes X/Y and separates false notifications", () => {
    // incident at 1-2; a noise blip at 5
    const d = mk([99, 90, 90, 99, 99, 90, 99], 1000, [1, 2]);
    const r = evaluate(d, { threshold: 96, persistence: 1, minVolume: 0 });
    expect(r.before).toMatchObject({ alerts: 3, detected: 1, total: 1, falseAlerts: 1 });
    expect(r.after).toMatchObject({ alerts: 2, detected: 1, missed: 0, falseAlerts: 1 });
    const strict = evaluate(d, { threshold: 96, persistence: 3, minVolume: 0 });
    expect(strict.after).toMatchObject({ detected: 0, missed: 1, alerts: 0 });
  });

  it("changing ground-truth labels never changes generated alerts", () => {
    const a = mk([99, 90, 90, 99, 90], 1000, [1, 2]);
    const b = a.map((x) => ({ ...x, incident: !x.incident }));
    const s = { threshold: 96, persistence: 2, minVolume: 0 };
    expect(thresholdAlerts(b, s)).toEqual(thresholdAlerts(a, s));
    expect(contextualTriage(b, s).notifications).toEqual(contextualTriage(a, s).notifications);
  });

  it("no breaches gives null reduction and zero counts, no NaN", () => {
    const r = evaluate(mk([99, 99]), DEFAULT_SETTINGS);
    expect(r.reduction).toBeNull();
    expect(r.after.alerts).toBe(0);
  });

  it.each(SCENARIOS.map((s) => s.id))("preset %s is deterministic, 96 samples, has an incident", (id) => {
    const d = getScenario(id);
    expect(d).toHaveLength(96);
    expect(d.some((x) => x.incident)).toBe(true);
    const r = evaluate(d, DEFAULT_SETTINGS);
    expect(Number.isFinite(r.reduction ?? 0)).toBe(true);
    expect(r.after.total).toBe(r.before.total);
  });
});
