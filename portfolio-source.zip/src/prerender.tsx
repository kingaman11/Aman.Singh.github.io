import { renderToString } from "react-dom/server";
import { RouterProvider, createMemoryHistory } from "@tanstack/react-router";
import { getRouter } from "./router";
export async function render() {
  const router = getRouter(createMemoryHistory({ initialEntries: [import.meta.env.BASE_URL] }), true);
  await router.load();
  return renderToString(<RouterProvider router={router} />);
}
