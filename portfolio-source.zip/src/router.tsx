import { QueryClient } from "@tanstack/react-query";
import { createRouter, type RouterHistory } from "@tanstack/react-router";
import { routeTree } from "./routeTree.gen";

export const getRouter = (history?: RouterHistory, isServer = false) => {
  const queryClient = new QueryClient();

  const router = createRouter({
    routeTree,
    ...(history ? { history } : {}),
    isServer,
    basepath: import.meta.env.BASE_URL,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0,
  });

  return router;
};
