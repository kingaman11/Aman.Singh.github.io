import { createFileRoute } from "@tanstack/react-router";
import portrait from "@/assets/aman-singh-portrait.jpeg";
import { useEffect, useRef, useState } from "react";
import { useInitialAnchor } from "@/hooks/use-initial-anchor";
import { useScrollSpy } from "@/hooks/use-scroll-spy";
import { useDiagramMotion } from "@/hooks/use-diagram-motion";
import type { ReactNode } from "react";
import { EventVisual, GuardianVisual, MexicoVisual } from "@/components/PracticeVisuals";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Monogram } from "@/components/Monogram";
import { CapabilityMap } from "@/components/CapabilityMap";
import { BasketballVisual, DavisPreview, EconometricsVisual } from "@/components/ProjectVisuals";
import { FeaturedStories } from "@/components/FeaturedStories";
import { AlertLab } from "@/components/AlertLab";
import { EducationLogos, LogoMarquee } from "@/components/LogoMarquee";
import { WorkFeatures } from "@/components/WorkFeatures";
import { Button } from "@/components/ui/button";
import { ArrowUpRight, CalendarDays, Github, Linkedin, Mail, Menu, Pause, Play, X } from "lucide-react";

export const Route = createFileRoute("/")({ component: Index });

const EMAIL = "amanorsingh1@gmail.com";
const LINKEDIN = "https://www.linkedin.com/in/amansinghh/";
const GITHUB = "https://github.com/kingaman11";
const CAL = "https://calendly.com/aman-singh1/30min";
const ext = { target: "_blank", rel: "noopener noreferrer" } as const;

const nav = [
  { href: "#projects", label: "Projects" },
  { href: "#work", label: "Work" },
  { href: "#experience", label: "Experience" },
  { href: "#expertise", label: "Expertise" },
  { href: "#about", label: "About" },
  { href: "#recommendations", label: "Recommendations" },
  { href: "#contact", label: "Contact" },
];


const roles: { org: string; role: string; note?: string; dates: string }[] = [
  { org: "C3 AI", role: "AI FDE Business Operations Manager", dates: "November 2026 – Present" },
  { org: "Roku", role: "Product & Payments Operations Manager", dates: "Oct 2025 – Oct 2026" },
  { org: "Georgia Tech", role: "Graduate Teaching Assistant → Instructional Associate", note: "Promoted in April 2026 · Graduate Regression & Analytics", dates: "Aug 2025 – Aug 2026" },
  { org: "Effective AI", role: "Go-to-Market Lead", dates: "2025 – Oct 2025" },
  { org: "Visa", role: "Senior Associate Product Manager", dates: "2022 – 2024" },
  { org: "Chevron", role: "Data Analyst", dates: "2021 – 2022" },
];

const education = [
  { school: "UC Berkeley Haas", detail: "MBA" },
  { school: "Georgia Institute of Technology", detail: "Data Analytics" },
  { school: "UC Davis", detail: "Economics & Applied Statistics, minor in Technology Management" },
];

const repos = [
  { name: "Davis Restaurant Analysis", desc: "An R/Shiny restaurant explorer for Davis built on the Yelp API — filter by price, category and restaurant to see details and review word clouds.", url: "https://github.com/kingaman11/Final.Project.STA141B", caption: "Project screenshot · academic work", visual: "davis" },
  { name: "Basketball Performance Analysis", desc: "An academic machine-learning exploration of basketball performance and BMI.", url: "https://github.com/kingaman11/Ecn190Final", caption: "Illustrative data · not project results", visual: "bball" },
  { name: "Econometrics", desc: "An academic analysis of a college-student dataset in Stata.", url: "https://github.com/kingaman11/Econometrics-Final", caption: "Illustrative analysis · not project results", visual: "econ" },
];

const practice = [
  {
    id: "events",
    tag: "Roku",
    title: "Event readiness & incident response",
    summary: "Designated payments operations DRI for Super Bowl LX; supported monitoring for F1, UFC, March Madness and the FIFA World Cup.",
    points: [
      "Before events: prepared runbooks and clear escalation paths.",
      "During events: shared hourly payment health snapshots.",
      "After events: led root-cause analysis and fed lessons back into the playbooks.",
    ],
  },
  {
    id: "mexico",
    tag: "Roku",
    title: "Mexico payment operations",
    summary: "Designed end-to-end payment testing across local and cross-border merchant accounts, channels, banks and card networks.",
    points: [
      "Investigated tokenization, expired-card declines and authorization issues.",
      "Coordinated responses across PSP partners (Adyen, Fiserv), product and engineering.",
    ],
  },
  {
    id: "guardian",
    tag: "Routing automation concept",
    title: "Roku Pay Guardian",
    summary: "An in-development concept for a two-agent approach to payment routing — not deployed.",
    points: [
      "A monitoring agent detects routes that underperform.",
      "Small canary probes on an alternate route allow a statistical comparison.",
      "The evidence informs routing decisions and reporting.",
    ],
  },
];

const principles = [
  ["Observe first", "Make a system visible before trying to optimize it."],
  ["Automate the routine", "Take repetitive reporting off people's plates so their time goes to judgment."],
  ["Let data clarify", "Use data to make the decision obvious, not to add noise."],
  ["Start small", "Test small changes, then expand once the evidence holds up."],
];

const recs = [
  { name: "Jeff Wang", title: "Product at Visa", rel: "Colleague on different teams", date: "Jan 3, 2026", quote: "Aman always brings a can-do attitude, intellectual curiosity and keen eye for detail that makes collaborating with him a joy." },
  { name: "Tomás Villena", title: "Product leader", rel: "Former direct manager", date: "July 5, 2024", quote: "Overall Aman is a very strong analytical thinker with problem-solving skills and an \u201calways learning\u201d mentality." },
  { name: "Amy Nguyen", title: "Data Science, Economics & Strategy", rel: "Mentorship", date: "Aug 29, 2024", quote: "His guidance is thoughtful, and he always goes the extra mile to ensure that his advice is both practical and actionable." },
  { name: "Brian Redmond, MBA", title: "IT Strategy & Planning Leader", rel: "Former direct manager", date: "Aug 4, 2022", quote: "In the year I worked with Aman, he was thoughtful, collaborative, and willing to take on new challenges. A great team player!" },
];

const exploring = [
  { t: "AI agents & internal tools", d: "Prototyping workflows that reduce repetitive reporting and coordination.", icon: "agents" },
  { t: "Planning & delivery visibility", d: "Exploring forecasting, capacity planning, and dashboards that make delivery health easier to understand.", icon: "plan" },
  { t: "Reliable tools over time", d: "Thinking beyond the prototype: monitoring, iteration, adoption, and ongoing maintenance.", icon: "loop" },
];

function ExploreIcon({ kind }: { kind: string }) {
  return (
    <svg viewBox="0 0 64 40" aria-hidden="true" className="h-10 w-16">
      {kind === "agents" && (
        <g strokeWidth="1.5" className="stroke-foreground/40">
          <line x1="14" y1="20" x2="32" y2="10" /><line x1="14" y1="20" x2="32" y2="30" /><line x1="32" y1="10" x2="50" y2="20" /><line x1="32" y1="30" x2="50" y2="20" />
          <circle cx="14" cy="20" r="5" className="fill-primary stroke-primary" /><circle cx="32" cy="10" r="4" className="fill-card" /><circle cx="32" cy="30" r="4" className="fill-card" /><circle cx="50" cy="20" r="5" className="fill-foreground stroke-foreground" />
        </g>
      )}
      {kind === "plan" && (
        <g>
          {[10, 18, 14, 24, 20].map((h, i) => <rect key={i} x={6 + i * 11} y={34 - h} width="7" height={h} rx="2" className={i === 4 ? "fill-primary" : "fill-foreground/25"} />)}
          <path d="M6 14 L60 6" strokeDasharray="2 3" strokeWidth="1.5" className="stroke-primary" />
        </g>
      )}
      {kind === "loop" && (
        <g fill="none" strokeWidth="1.5">
          <circle cx="32" cy="20" r="13" strokeDasharray="3 3" className="stroke-foreground/40" />
          <circle cx="45" cy="20" r="4" className="fill-primary stroke-primary" />
          <circle cx="19" cy="20" r="3" className="fill-card stroke-foreground/60" />
        </g>
      )}
    </svg>
  );
}

const certifications = ["Product Manager Certification", "Lean Six Sigma Green Belt", "Excel Modeling"];

const VISUALS: Record<string, ReactNode> = { events: <EventVisual />, mexico: <MexicoVisual />, guardian: <GuardianVisual /> };
const CAPTIONS: Record<string, string> = { events: "Illustrative workflow", mexico: "Illustrative test coverage", guardian: "Illustrative architecture · concept, not deployed" };

function PracticePanel({ p }: { p: (typeof practice)[number] }) {
  const [open, setOpen] = useState(false);
  const panelId = `practice-${p.id}`;
  return (
    <article className="card-lift flex min-w-0 flex-col overflow-hidden rounded-2xl border border-border bg-card">
      <figure className={`viz ${p.id === "mexico" ? "surface-light" : "surface-ink"} bg-fine-grid border-b border-border p-4`}>
        {VISUALS[p.id]}
        <figcaption className="mt-3 text-xs leading-snug text-muted-foreground">{CAPTIONS[p.id]}</figcaption>
      </figure>
      <div className="flex flex-1 flex-col p-6">
      <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{p.tag}</p>
      <h4 className="mt-3 font-display text-xl">{p.title}</h4>
      <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{p.summary}</p>
      <button
        type="button"
        aria-expanded={open}
        aria-controls={panelId}
        onClick={() => setOpen(!open)}
        className="mt-5 inline-flex items-center gap-1 self-start text-sm font-medium text-foreground underline decoration-border underline-offset-4 hover:text-primary hover:decoration-primary"
      >
        {open ? "Hide details" : "Show details"} <span aria-hidden="true">{open ? "−" : "+"}</span>
      </button>
      <ul id={panelId} hidden={!open} className="mt-4 space-y-2 border-t border-border pt-4 text-sm leading-relaxed text-muted-foreground">
        {p.points.map((pt) => (
          <li key={pt} className="flex gap-3"><span aria-hidden="true" className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />{pt}</li>
        ))}
      </ul>
      </div>
    </article>
  );
}


function Network() {
  const nodes: [number, number][] = [[40, 60], [160, 30], [260, 110], [120, 170], [320, 40], [360, 190], [220, 230]];
  const edges: [number, number][] = [[0, 1], [1, 2], [0, 3], [3, 2], [1, 4], [4, 2], [2, 5], [3, 6], [6, 5]];
  return (
    <svg viewBox="0 0 400 260" aria-hidden="true" className="h-full w-full text-foreground/25">
      {edges.map(([a, b], i) => (
        <line key={i} x1={nodes[a]![0]} y1={nodes[a]![1]} x2={nodes[b]![0]} y2={nodes[b]![1]} stroke="currentColor" strokeWidth="1" />
      ))}
      {nodes.map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r={i === 2 ? 6 : 3.5} className={i === 2 ? "fill-primary" : "fill-background stroke-foreground/40"} strokeWidth="1" />
      ))}
    </svg>
  );
}

function SectionHead({ n, title, id }: { n: string; title: string; id: string }) {
  return (
    <div className="mb-10 flex items-baseline gap-4 border-t border-foreground/15 pt-6 sm:mb-12">
      <span className="font-mono text-xs text-primary">{n}</span>
      <h2 id={id} className="font-display text-4xl font-light tracking-tight sm:text-5xl">{title}</h2>
    </div>
  );
}

function Index() {
  useInitialAnchor();
  const [open, setOpen] = useState(false);
  const active = useScrollSpy();
  const diagramMotion = useDiagramMotion();
  const navRef = useRef<HTMLUListElement>(null);
  const [bar, setBar] = useState({ x: 0, w: 0 });
  useEffect(() => {
    const ul = navRef.current;
    if (!ul) return;
    const measure = () => {
      const a = active ? ul.querySelector<HTMLElement>(`a[data-href="${active}"]`) : null;
      setBar(a && ul.offsetWidth ? { x: a.offsetLeft, w: a.offsetWidth } : { x: 0, w: 0 });
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(ul);
    return () => ro.disconnect();
  }, [active]);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || !("IntersectionObserver" in window)) return;
    const els = [...document.querySelectorAll<HTMLElement>(".reveal")].filter((el) => el.getBoundingClientRect().top > window.innerHeight);
    const io = new IntersectionObserver((entries) => {
      for (const e of entries) if (e.isIntersecting) { e.target.classList.add("is-visible"); io.unobserve(e.target); }
    }, { rootMargin: "0px 0px -8% 0px" });
    els.forEach((el) => { el.classList.add("reveal-pending"); io.observe(el); });
    return () => { io.disconnect(); els.forEach((el) => el.classList.remove("reveal-pending")); };
  }, []);

  return (
    <div className="min-h-screen overflow-x-hidden">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground">
        Skip to content
      </a>

      <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 sm:px-8">
          <Monogram />
          <nav aria-label="Primary" className="hidden lg:block">
            <ul ref={navRef} className="relative flex items-center gap-6 text-sm">
              {nav.map((n) => (
                <li key={n.href}><a href={n.href} data-href={n.href} aria-current={active === n.href ? "location" : undefined} className={`transition-colors hover:text-foreground ${active === n.href ? "text-foreground" : "text-muted-foreground"}`}>{n.label}</a></li>
              ))}
              <span aria-hidden="true" className="nav-indicator" style={{ transform: `translateX(${bar.x}px) scaleX(${bar.w})`, opacity: bar.w ? 1 : 0 }} />
            </ul>
          </nav>
          <div className="hidden items-center gap-1 lg:flex">
            <a href={LINKEDIN} {...ext} aria-label="LinkedIn (opens in new tab)" className="flex h-10 w-10 items-center justify-center rounded-full text-muted-foreground hover:text-primary"><Linkedin size={18} /></a>
            <a href={GITHUB} {...ext} aria-label="GitHub (opens in new tab)" className="flex h-10 w-10 items-center justify-center rounded-full text-muted-foreground hover:text-primary"><Github size={18} /></a>
            <ThemeToggle />
          </div>
          <div className="flex items-center gap-2 lg:hidden">
          <ThemeToggle />
          <button type="button" className="flex h-11 w-11 items-center justify-center rounded-full" aria-expanded={open} aria-controls="mobile-nav" aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen(!open)}>
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
          </div>
        </div>
        {open && (
          <nav id="mobile-nav" aria-label="Mobile" className="border-t border-border bg-background px-5 pb-6 lg:hidden">
            <ul className="flex flex-col">
              {nav.map((n) => (
                <li key={n.href}>
                  <a href={n.href} onClick={() => setOpen(false)} aria-current={active === n.href ? "location" : undefined} className={`block border-b border-border py-4 font-display text-2xl ${active === n.href ? "text-primary" : ""}`}>{n.label}</a>
                </li>
              ))}
            </ul>
            <div className="mt-5 flex gap-5">
              <a href={LINKEDIN} {...ext} className="flex min-h-11 items-center gap-2 text-sm"><Linkedin size={18} /> LinkedIn</a>
              <a href={GITHUB} {...ext} className="flex min-h-11 items-center gap-2 text-sm"><Github size={18} /> GitHub</a>
            </div>
          </nav>
        )}
      </header>

      <main id="main">
        <section id="top" className="relative bg-fine-grid">
          <div className="relative mx-auto max-w-6xl px-5 pb-16 pt-12 sm:px-8 sm:pt-20">
            <div className="grid grid-cols-[minmax(0,1fr)] items-center gap-8 lg:grid-cols-[minmax(0,1fr)_auto] lg:gap-14">
            <div className="w-full min-w-0 lg:order-2 lg:w-[340px]">
              <div className="fade-up h-[200px] w-[200px] overflow-hidden rounded-3xl border border-border bg-card p-1.5 shadow-sm sm:h-[240px] sm:w-[240px] lg:h-[340px] lg:w-[340px]">
                <img src={portrait} alt="Aman Singh" width={400} height={400} decoding="async" fetchPriority="high" className="h-full w-full rounded-[1.1rem] object-cover object-[50%_30%]" />
              </div>
              <LogoMarquee />
              <EducationLogos />
            </div>
            <div className="min-w-0 lg:order-1">
            <p className="fade-up font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">Product &amp; AI Operations</p>
            <h1 className="fade-up mt-5 font-display text-[clamp(3.25rem,11vw,8.5rem)] font-normal leading-[0.9] tracking-tight">Aman Singh</h1>
            <p className="fade-up mt-6 max-w-4xl font-display text-[clamp(1.75rem,4.6vw,3.5rem)] font-light leading-[1.05] tracking-tight">
              Turning complexity into <em className="text-primary">reliable</em> systems.
            </p>
            <p className="fade-up mt-8 max-w-xl text-lg leading-relaxed text-muted-foreground">
              I work at the intersection of AI, operations, and payments—turning complex workflows into reliable systems and clear decisions.
            </p>
            <div className="fade-up mt-10 flex flex-wrap gap-3 [&>a]:min-h-11">
              <a href="#projects" className="inline-flex items-center gap-2 rounded-full bg-foreground px-6 py-3 text-sm font-medium text-background transition-colors hover:bg-primary">View my work</a>
<a href={CAL} {...ext} className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-foreground hover:text-background"><CalendarDays size={16} /> Book a 30-minute chat</a>
              <a href={`mailto:${EMAIL}`} className="inline-flex items-center gap-2 rounded-full border border-foreground/30 px-6 py-3 text-sm font-medium transition-colors hover:border-primary hover:text-primary"><Mail size={16} /> Let's connect</a>
            </div>
            </div>
            </div>

            <dl className="mt-14 grid gap-px overflow-hidden rounded-2xl border border-border bg-border sm:grid-cols-3">
              {[
                ["146+", "payment KPIs", "Monitored at Roku"],
                ["5", "regions monitored", "Payments, Roku"],
                ["90%", "faster reporting", "KPI automation, Visa"],
              ].map(([v, l, c]) => (
                <div key={l} className="bg-card p-6">
                  <dt className="sr-only">{l}</dt>
                  <dd className="font-display text-5xl font-light">{v}</dd>
                  <dd className="mt-2 text-sm font-medium">{l}</dd>
                  <dd className="font-mono text-xs text-muted-foreground">{c}</dd>
                </div>
              ))}
            </dl>
          </div>
        </section>

        <section aria-labelledby="work-h" id="work" className="reveal mx-auto max-w-6xl px-5 py-20 sm:px-8 sm:py-28">
          <SectionHead n="01" title="Selected work" id="work-h" />
          <div className="-mt-4 mb-10 flex flex-wrap items-center justify-between gap-x-6 gap-y-2">
            <p className="max-w-[65ch] text-muted-foreground">Selected highlights across payments, product strategy, and operational analytics.</p>
            <Button variant="ghost" className="min-h-11 shrink-0 text-muted-foreground" aria-label={diagramMotion.paused ? "Resume workflow motion" : "Pause workflow motion"} aria-pressed={diagramMotion.paused} onClick={diagramMotion.togglePaused}>
              {diagramMotion.paused ? <Play aria-hidden="true" /> : <Pause aria-hidden="true" />}
              Workflow motion
            </Button>
          </div>
          <div id="projects" className="scroll-mt-20">
            <FeaturedStories />
          </div>
          <AlertLab />
          <div id="more-work" className="mt-24">
            <h3 className="mb-6 font-display text-3xl">More selected work</h3>
            <WorkFeatures />
          </div>

          <div id="payments-practice" className="mt-20 scroll-mt-20">
            <p className="text-sm text-muted-foreground">At Roku</p>
            <h3 className="mt-1 font-display text-3xl">Payments in practice</h3>
            <div className="mt-6 grid items-start gap-5 md:grid-cols-2 xl:grid-cols-3">
              {practice.map((p) => <PracticePanel key={p.id} p={p} />)}
            </div>
          </div>

          <div id="academic-projects" className="mt-20 scroll-mt-20">
            <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Academic work on GitHub</p>
                <h3 className="mt-1 font-display text-3xl">Academic projects</h3>
              </div>
              <a href={GITHUB} {...ext} className="inline-flex items-center gap-1 text-sm font-medium text-foreground underline decoration-border underline-offset-4 hover:text-primary hover:decoration-primary">View all on GitHub <ArrowUpRight size={16} /></a>
            </div>
            <div className="grid gap-5 md:grid-cols-3">
              {repos.map((r) => (
                <a key={r.url} href={r.url} {...ext} className="card-lift group flex min-w-0 flex-col overflow-hidden rounded-2xl border border-border bg-card">
                  <figure className={`viz ${r.visual === "econ" || (r.visual !== "davis" && r.visual !== "bball") ? "surface-ink" : r.visual === "bball" ? "surface-warm" : "surface-light"} bg-fine-grid border-b border-border p-4`}>
                    {r.visual === "davis" ? <DavisPreview /> : r.visual === "bball" ? <BasketballVisual /> : <EconometricsVisual />}
                    <figcaption className="mt-3 text-xs leading-snug text-muted-foreground">{r.caption}</figcaption>
                  </figure>
                  <div className="flex flex-1 flex-col p-6">
                  <Github size={18} className="text-muted-foreground" />
                  <h4 className="mt-4 font-display text-xl">{r.name}</h4>
                  <p className="mt-2 flex-1 text-sm text-muted-foreground">{r.desc}</p>
                  <span className="mt-6 inline-flex items-center gap-1 text-sm font-medium text-primary">View repository <ArrowUpRight size={14} className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /></span>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </section>

        <section aria-labelledby="exp-h" id="experience" className="reveal mx-auto max-w-6xl px-5 py-20 sm:px-8 sm:py-28">
          <SectionHead n="02" title="Experience" id="exp-h" />
          <ol className="divide-y divide-border border-y border-border">
            {roles.map((r) => (
              <li key={r.role} className="grid gap-1 py-6 sm:grid-cols-[10rem_1fr_auto] sm:items-baseline sm:gap-6">
                <span className="font-display text-xl">{r.org}</span>
                <span className="text-muted-foreground">
                  {r.role}
                  {r.note && <span className="mt-1 block font-mono text-xs text-muted-foreground/80">{r.note}</span>}
                </span>
                <span className="font-mono text-xs text-muted-foreground">{r.dates}</span>
              </li>
            ))}
          </ol>

          <div className="mt-20 grid gap-12 lg:grid-cols-2">
            <div>
              <h3 className="font-display text-3xl">Education</h3>
              <ul className="mt-6 space-y-5">
                {education.map((e) => (
                  <li key={e.school}><p className="font-medium">{e.school}</p><p className="text-sm text-muted-foreground">{e.detail}</p></li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="font-display text-3xl">Certifications</h3>
              <ul className="mt-6 space-y-2">
                {certifications.map((c) => <li key={c} className="font-medium">{c}</li>)}
              </ul>
            </div>
          </div>
          <div id="expertise" aria-labelledby="expertise-h" role="region" className="mt-20 scroll-mt-20">
            <CapabilityMap />
          </div>
        </section>

        <section aria-labelledby="about-h" id="about" className="reveal mx-auto max-w-6xl px-5 py-20 sm:px-8 sm:py-28">
          <SectionHead n="03" title="About" id="about-h" />
          <div className="grid gap-10 lg:grid-cols-[1fr_2fr]">
            <div className="hidden h-48 rounded-2xl border border-border bg-fine-grid lg:block"><Network /></div>
            <div className="max-w-[65ch] space-y-5 text-lg leading-relaxed">
              <p>I'm a product and operations professional based in the San Francisco Bay Area. My work sits where payments, data and AI meet — the places where small signals can carry real financial weight.</p>
              <p className="text-muted-foreground">I've monitored payment performance at Roku, built forecasts and automation at Visa, created dashboards at Chevron and led go-to-market research at Effective AI. Along the way I've supported graduate students in regression and analytics at Georgia Tech.</p>
              <p className="text-muted-foreground">My focus is expanding toward AI-enabled operations: internal tools, workflow automation, and clearer visibility into delivery health. I'm interested in connecting the operating cadence of a team with the agents and applications that support it.</p>
              <p className="text-muted-foreground">What ties it together: making complex systems easier to understand, and more reliable to run.</p>
            </div>
          </div>
        </section>

        <section aria-labelledby="how-h" className="reveal mx-auto max-w-6xl px-5 pb-20 sm:px-8 sm:pb-28">
          <h3 id="how-h" className="font-display text-3xl">How I work</h3>
          <ol className="mt-8 grid gap-px overflow-hidden rounded-2xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
            {principles.map(([t, d], i) => (
              <li key={t} className="bg-card p-6">
                <span className="font-mono text-xs text-primary">0{i + 1}</span>
                <p className="mt-3 font-display text-xl">{t}</p>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{d}</p>
              </li>
            ))}
          </ol>
          <div className="mt-16">
            <h3 className="font-display text-3xl">Exploring next</h3>
            <p className="mt-2 text-sm text-muted-foreground">Areas of interest and focus I'm developing.</p>
            <ul className="mt-6 grid gap-5 md:grid-cols-3">
              {exploring.map((e) => (
                <li key={e.t} className="rounded-2xl border border-border bg-card p-6">
                  <ExploreIcon kind={e.icon} />
                  <p className="mt-4 font-display text-xl">{e.t}</p>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{e.d}</p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section aria-labelledby="recs-h" id="recommendations" className="reveal mx-auto max-w-6xl px-5 py-20 sm:px-8 sm:py-28">
          <SectionHead n="04" title="Recommendations" id="recs-h" />
          <p className="-mt-6 mb-10 text-sm text-muted-foreground">Excerpts from LinkedIn recommendations</p>
          <div className="grid gap-5 md:grid-cols-2">
            {recs.map((r) => (
              <figure key={r.name} className="flex flex-col rounded-2xl border border-border bg-card p-7 sm:p-8">
                <blockquote className="flex-1 font-display text-xl font-light leading-snug">
                  <p>“{r.quote}”</p>
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-3 border-t border-border pt-5">
                  <span aria-hidden="true" className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-accent font-mono text-xs text-accent-foreground">
                    {r.name.split(" ").slice(0, 2).map((w) => w[0]).join("")}
                  </span>
                  <span className="min-w-0">
                    <span className="block font-medium">{r.name}</span>
                    <span className="block text-sm text-muted-foreground">{r.title}</span>
                    <span className="block font-mono text-xs text-muted-foreground">{r.rel} · {r.date}</span>
                  </span>
                </figcaption>
              </figure>
            ))}
          </div>
          <a href="https://www.linkedin.com/in/amansinghh/details/recommendations/" {...ext} className="mt-8 inline-flex items-center gap-1 text-sm font-medium text-foreground underline decoration-border underline-offset-4 hover:text-primary hover:decoration-primary">
            Read more recommendations on LinkedIn <ArrowUpRight size={14} />
          </a>
        </section>

        <section aria-labelledby="contact-h" id="contact" className="px-3 pb-3 pt-8 sm:px-5 sm:pb-5">
          <div className="reveal mx-auto max-w-7xl overflow-hidden rounded-[2rem] bg-ink text-ink-foreground ring-1 ring-ink-foreground/10">
            <div className="mx-auto max-w-6xl px-6 py-20 sm:px-10 sm:py-28">
              <p className="text-sm text-ink-foreground/70">Contact</p>
              <h2 id="contact-h" className="mt-4 max-w-[16ch] font-display text-[clamp(2.5rem,7vw,5.5rem)] font-light leading-[0.98] tracking-tight">
                Let’s build something useful.
              </h2>
              <p className="mt-6 max-w-[55ch] text-lg leading-relaxed text-ink-foreground/75">Let's talk about AI, operations, and reliable systems.</p>
              <a href={CAL} {...ext} className="mt-10 inline-flex min-h-12 items-center gap-2 rounded-full bg-primary px-7 py-3.5 text-base font-medium text-primary-foreground transition-transform hover:-translate-y-0.5 focus-visible:outline-ink-foreground">
                <CalendarDays size={18} /> Book a 30-minute chat
              </a>
              <ul className="mt-10 flex flex-wrap gap-x-8 gap-y-2 text-sm">
                <li><a href={`mailto:${EMAIL}`} className="inline-flex min-h-11 items-center gap-2 break-all text-ink-foreground/85 underline-offset-4 hover:text-ink-foreground hover:underline"><Mail size={16} /> {EMAIL}</a></li>
                <li><a href={LINKEDIN} {...ext} className="inline-flex min-h-11 items-center gap-2 text-ink-foreground/85 underline-offset-4 hover:text-ink-foreground hover:underline"><Linkedin size={16} /> LinkedIn</a></li>
                <li><a href={GITHUB} {...ext} className="inline-flex min-h-11 items-center gap-2 text-ink-foreground/85 underline-offset-4 hover:text-ink-foreground hover:underline"><Github size={16} /> GitHub</a></li>
              </ul>
            </div>
            <footer className="border-t border-ink-foreground/15">
              <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-6 py-6 text-sm text-ink-foreground/60 sm:px-10">
                <p>© {new Date().getFullYear()} Aman Singh · San Francisco Bay Area</p>
                <a href="#top" className="inline-flex min-h-11 items-center hover:text-ink-foreground">Back to top ↑</a>
              </div>
            </footer>
          </div>
        </section>
      </main>
    </div>
  );
}
